# EDU-PINJAM
Aplikasi simpan pinjam inventaris perlengkapan sekolah (Kotlin, Jetpack Compose, MVVM, Room, DataStore).

## Cara menjalankan
1. Buka folder ini di Android Studio (Koala / 2024.1 atau lebih baru), JDK 17.
2. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh dependensi).
3. Run pada emulator/perangkat Android 7.0+ (API 24+).

## Akun demo
- Admin: `admin` / `admin123`
- Petugas: `petugas` / `petugas123`
- Siswa: NIS `1001` / `siswa123` (juga 1002, 1003)

Data awal (15 barang + contoh peminjaman) dibuat otomatis saat pertama kali dibuka.
