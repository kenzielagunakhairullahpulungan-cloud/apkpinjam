package com.edupinjam.app.ui.theme

import androidx.compose.ui.graphics.Color

// Palet utama EDU-PINJAM
val SkyBlue = Color(0xFF0284C7)        // tombol dan header
val SkyLight = Color(0xFFE0F2FE)       // latar kartu
val TextDark = Color(0xFF0F172A)       // teks utama
val White = Color(0xFFFFFFFF)          // latar utama
val SkyDeep = Color(0xFF0369A1)        // varian lebih tua untuk gradasi header
val TextMuted = Color(0xFF475569)      // teks sekunder

// Warna status
val GreenOk = Color(0xFF16A34A)
val GreenOkBg = Color(0xFFDCFCE7)
val YellowWarn = Color(0xFFB45309)
val YellowWarnBg = Color(0xFFFEF3C7)
val RedBad = Color(0xFFDC2626)
val RedBadBg = Color(0xFFFEE2E2)

// Palet mode gelap (biru malam, bukan hitam pekat)
val NightBg = Color(0xFF0B2A43)
val NightSurface = Color(0xFF123A5A)
val NightText = Color(0xFFE0F2FE)
val SkyAccent = Color(0xFF38BDF8)
