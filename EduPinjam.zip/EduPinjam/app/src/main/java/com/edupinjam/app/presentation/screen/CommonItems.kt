package com.edupinjam.app.presentation.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edupinjam.app.data.local.BarangEntity
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.domain.Denda
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.ui.components.BarangImage
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.StatusBadge
import com.edupinjam.app.ui.components.StokBadge
import com.edupinjam.app.ui.components.stokColor
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.utils.DateUtils
import com.edupinjam.app.utils.RupiahFormat

/** Kartu barang: foto, nama, stok, dan badge status stok */
@Composable
fun BarangCard(b: BarangEntity, onClick: () -> Unit, modifier: Modifier = Modifier) {
    EduCard(modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BarangImage(b.fotoPath, ukuran = 68.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(b.nama, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${b.kategori} - ${b.kode}", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Stok ${b.stokTersedia}/${b.stokTotal}", fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp, color = stokColor(b.stokTersedia)
                    )
                    Spacer(Modifier.width(8.dp))
                    StokBadge(b.stokTersedia)
                }
            }
        }
    }
}

/**
 * Kartu peminjaman. [aksi] adalah slot tombol opsional (misalnya tombol Kembalikan).
 * Denda berjalan dihitung langsung untuk pinjaman yang masih aktif dan terlambat.
 */
@Composable
fun PeminjamanItem(
    d: PeminjamanDetail,
    modifier: Modifier = Modifier,
    tampilkanSiswa: Boolean = true,
    onClick: (() -> Unit)? = null,
    aksi: (@Composable () -> Unit)? = null
) {
    val p = d.peminjaman
    val dendaSekarang = if (StatusPinjam.aktif(p.status)) {
        Denda.hitung(p.tanggalJatuhTempo, System.currentTimeMillis())
    } else p.denda

    EduCard(modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BarangImage(d.fotoBarang, ukuran = 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "${d.namaBarang} x${p.jumlah}", fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (tampilkanSiswa) {
                    Text("${d.namaSiswa} (${d.nisSiswa})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    "${DateUtils.formatTanggal(p.tanggalPinjam)} - ${DateUtils.formatTanggal(p.tanggalJatuhTempo)}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            StatusBadge(p.status)
        }
        if (p.keperluan.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text("Keperluan: ${p.keperluan}", fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (dendaSekarang > 0) {
            val hari = (dendaSekarang / Denda.PER_HARI).toInt()
            Spacer(Modifier.height(4.dp))
            Text(
                "Terlambat $hari hari - Denda ${RupiahFormat.format(dendaSekarang)}",
                color = RedBad, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
        }
        p.tanggalKembali?.let {
            Spacer(Modifier.height(2.dp))
            Text("Dikembalikan: ${DateUtils.formatTanggalJam(it)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (aksi != null) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { aksi() }
        }
    }
}
