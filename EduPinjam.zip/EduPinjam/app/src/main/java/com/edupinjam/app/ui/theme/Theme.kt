package com.edupinjam.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightScheme = lightColorScheme(
    primary = SkyBlue,
    onPrimary = White,
    primaryContainer = SkyLight,
    onPrimaryContainer = TextDark,
    secondary = SkyDeep,
    onSecondary = White,
    secondaryContainer = SkyLight,
    onSecondaryContainer = TextDark,
    background = White,
    onBackground = TextDark,
    surface = White,
    onSurface = TextDark,
    surfaceVariant = SkyLight,
    onSurfaceVariant = TextMuted,
    outline = SkyBlue,
    outlineVariant = SkyLight,
    error = RedBad,
    onError = White
)

private val DarkScheme = darkColorScheme(
    primary = SkyAccent,
    onPrimary = TextDark,
    primaryContainer = NightSurface,
    onPrimaryContainer = NightText,
    secondary = SkyAccent,
    onSecondary = TextDark,
    secondaryContainer = NightSurface,
    onSecondaryContainer = NightText,
    background = NightBg,
    onBackground = NightText,
    surface = NightBg,
    onSurface = NightText,
    surfaceVariant = NightSurface,
    onSurfaceVariant = NightText,
    outline = SkyAccent,
    outlineVariant = NightSurface,
    error = RedBad,
    onError = White
)

/** Sudut membulat 16dp untuk kartu, 12dp untuk tombol dan input */
private val EduShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun EduPinjamTheme(modeGelap: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (modeGelap) DarkScheme else LightScheme,
        shapes = EduShapes,
        content = content
    )
}
