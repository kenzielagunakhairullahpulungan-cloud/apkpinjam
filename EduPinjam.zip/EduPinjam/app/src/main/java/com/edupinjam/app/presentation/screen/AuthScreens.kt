@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.edupinjam.app.domain.Role
import com.edupinjam.app.presentation.viewmodel.AuthViewModel
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTextField
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.SkyDeep
import com.edupinjam.app.ui.theme.White

/** Logo EDU-PINJAM: lingkaran sky blue dengan ikon sekolah putih */
@Composable
fun LogoEduPinjam(ukuran: Int = 96, terbalik: Boolean = false) {
    Box(
        Modifier
            .size(ukuran.dp)
            .clip(CircleShape)
            .background(if (terbalik) White else SkyBlue),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Filled.School, contentDescription = "Logo",
            tint = if (terbalik) SkyBlue else White,
            modifier = Modifier.size((ukuran * 0.56f).dp)
        )
    }
}

/** Splash screen: logo sky blue di latar putih */
@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(White), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LogoEduPinjam(120)
            Spacer(Modifier.height(20.dp))
            Text("EDU-PINJAM", color = SkyBlue, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text("Simpan Pinjam Inventaris Sekolah", color = SkyDeep, fontSize = 14.sp)
            Spacer(Modifier.height(32.dp))
            CircularProgressIndicator(color = SkyBlue, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        }
    }
}

/** Header gradasi sky blue untuk layar login dan register */
@Composable
private fun HeaderAuth(judul: String, sub: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.verticalGradient(listOf(SkyBlue, SkyDeep)))
            .padding(top = 48.dp, bottom = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LogoEduPinjam(72, terbalik = true)
            Spacer(Modifier.height(12.dp))
            Text(judul, color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = White.copy(alpha = 0.9f), fontSize = 13.sp)
        }
    }
}

/** Layar login dengan pilihan peran Siswa / Petugas / Admin */
@Composable
fun LoginScreen(vm: AuthViewModel, onRegister: () -> Unit) {
    var peran by remember { mutableStateOf(Role.SISWA) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val proses by vm.sedangProses.collectAsStateWithLifecycle()
    val pesan by vm.pesan.collectAsStateWithLifecycle()

    // Bersihkan pesan lama ketika layar dibuka
    LaunchedEffect(Unit) { vm.bersihkanPesan() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        HeaderAuth("EDU-PINJAM", "Masuk untuk meminjam perlengkapan sekolah")
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Masuk sebagai", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(Role.SISWA, Role.PETUGAS, Role.ADMIN).forEach { r ->
                    FilterChip(
                        selected = peran == r,
                        onClick = { peran = r; vm.bersihkanPesan() },
                        label = { Text(Role.label(r)) },
                        shape = RoundedCornerShape(12.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SkyBlue, selectedLabelColor = White
                        )
                    )
                }
            }
            EduTextField(
                value = username, onValueChange = { username = it },
                label = if (peran == Role.SISWA) "NIS" else "Username"
            )
            EduTextField(value = password, onValueChange = { password = it }, label = "Password", password = true)

            pesan?.let { Text(it, color = RedBad, fontSize = 13.sp) }

            PrimaryButton(
                text = if (proses) "Memproses..." else "Masuk",
                onClick = { vm.login(peran, username, password) },
                enabled = !proses,
                modifier = Modifier.fillMaxWidth()
            )

            if (peran == Role.SISWA) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text("Belum punya akun?")
                    TextButton(onClick = onRegister) { Text("Daftar Siswa", color = SkyBlue, fontWeight = FontWeight.Bold) }
                }
            }

            // Info akun demo agar mudah dicoba
            EduCard(Modifier.fillMaxWidth()) {
                Text("Akun demo", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Admin: admin / admin123", fontSize = 13.sp)
                Text("Petugas: petugas / petugas123", fontSize = 13.sp)
                Text("Siswa: NIS 1001 / siswa123", fontSize = 13.sp)
            }
        }
    }
}

/** Layar pendaftaran siswa baru */
@Composable
fun RegisterScreen(vm: AuthViewModel, onBack: () -> Unit) {
    var nama by remember { mutableStateOf("") }
    var nis by remember { mutableStateOf("") }
    var kelas by remember { mutableStateOf("") }
    var noHp by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val proses by vm.sedangProses.collectAsStateWithLifecycle()
    val pesan by vm.pesan.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.bersihkanPesan() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Daftar Siswa Baru", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            EduTextField(nama, { nama = it }, "Nama Lengkap")
            EduTextField(nis, { nis = it.filter { c -> c.isDigit() } }, "NIS", keyboardType = KeyboardType.Number)
            EduTextField(kelas, { kelas = it }, "Kelas (contoh: X IPA 1)")
            EduTextField(noHp, { noHp = it.filter { c -> c.isDigit() } }, "No HP", keyboardType = KeyboardType.Phone)
            EduTextField(password, { password = it }, "Password (min. 6 karakter)", password = true)
            pesan?.let { Text(it, color = RedBad, fontSize = 13.sp, textAlign = TextAlign.Start) }
            PrimaryButton(
                text = if (proses) "Memproses..." else "Daftar",
                onClick = { vm.register(nama, nis, kelas, noHp, password) },
                enabled = !proses,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
