package com.edupinjam.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.data.preferences.SessionManager
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.domain.LaporanBuilder
import com.edupinjam.app.domain.LaporanBulanan
import com.edupinjam.app.domain.OpResult
import com.edupinjam.app.utils.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** ViewModel laporan bulanan */
class LaporanViewModel(repo: AppRepository) : ViewModel() {

    val bulan = MutableStateFlow(DateUtils.awalBulan(System.currentTimeMillis()))

    val laporan: StateFlow<LaporanBulanan> = combine(bulan, repo.observePeminjaman()) { b, semua ->
        LaporanBuilder.susun(DateUtils.formatBulan(b), b, DateUtils.akhirBulan(b), semua)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000),
        LaporanBulanan("", 0, 0, 0L, emptyList(), emptyList(), emptyList())
    )

    fun geser(delta: Int) {
        bulan.value = DateUtils.geserBulan(bulan.value, delta)
    }
}

/** ViewModel profil, pengaturan, kelola petugas, dan ganti password */
class ProfilViewModel(
    private val repo: AppRepository,
    private val session: SessionManager,
    private val userId: Long
) : ViewModel() {

    val user: StateFlow<UserEntity?> = repo.observeUser(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val totalPinjam: StateFlow<Int> = repo.observeTotalPinjamUser(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val daftarPetugas: StateFlow<List<UserEntity>> = repo.observePetugas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val modeGelap: StateFlow<Boolean> = session.modeGelap
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val pengingat: StateFlow<Boolean> = session.pengingatAktif
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun setModeGelap(aktif: Boolean) {
        viewModelScope.launch { session.setModeGelap(aktif) }
    }

    fun setPengingat(aktif: Boolean) {
        viewModelScope.launch { session.setPengingat(aktif) }
    }

    fun logout() {
        viewModelScope.launch { session.hapusSesi() }
    }

    fun gantiPassword(lama: String, baru: String, selesai: (OpResult<Unit>) -> Unit) {
        viewModelScope.launch { selesai(repo.gantiPassword(userId, lama, baru)) }
    }

    fun updateProfil(nama: String, kelas: String, noHp: String, foto: String?, selesai: (OpResult<Unit>) -> Unit) {
        viewModelScope.launch { selesai(repo.updateProfil(userId, nama, kelas, noHp, foto)) }
    }

    fun tambahPetugas(nama: String, username: String, password: String, selesai: (OpResult<Long>) -> Unit) {
        viewModelScope.launch { selesai(repo.tambahPetugas(nama, username, password)) }
    }

    fun hapusPetugas(u: UserEntity) {
        viewModelScope.launch { repo.hapusPetugas(u) }
    }
}
