package com.edupinjam.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/** Database Room utama aplikasi EDU-PINJAM */
@Database(
    entities = [UserEntity::class, BarangEntity::class, PeminjamanEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun barangDao(): BarangDao
    abstract fun peminjamanDao(): PeminjamanDao

    companion object {
        const val NAMA_DB = "edupinjam.db"

        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    NAMA_DB
                ).build().also { instance = it }
            }

        /** Menutup database, dipakai sebelum restore backup */
        fun tutup() {
            synchronized(this) {
                instance?.close()
                instance = null
            }
        }
    }
}
