package com.edupinjam.app.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** Utilitas penyimpanan foto ke penyimpanan internal aplikasi */
object ImageUtils {

    private fun folderFoto(context: Context): File =
        File(context.filesDir, "foto").apply { mkdirs() }

    /** File tujuan baru untuk foto kamera */
    fun fileBaru(context: Context, prefix: String): File =
        File(folderFoto(context), "${prefix}_${System.currentTimeMillis()}.jpg")

    fun uriUntukFile(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /** Salin gambar dari galeri ke penyimpanan internal (dikecilkan agar hemat ruang) */
    fun salinDariUri(context: Context, uri: Uri, prefix: String): String? = try {
        val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: return null
        val file = fileBaru(context, prefix)
        simpanKecil(bitmap, file)
        file.absolutePath
    } catch (e: Exception) {
        null
    }

    /** Kecilkan foto hasil kamera (sisi terpanjang 1024px) lalu timpa file aslinya */
    fun kecilkanFile(path: String) {
        try {
            val bitmap = BitmapFactory.decodeFile(path) ?: return
            simpanKecil(bitmap, File(path))
        } catch (_: Exception) {
        }
    }

    private fun simpanKecil(bitmap: Bitmap, file: File) {
        val maks = 1024
        val skala = maks.toFloat() / maxOf(bitmap.width, bitmap.height)
        val hasil = if (skala < 1f) {
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * skala).toInt(), (bitmap.height * skala).toInt(), true)
        } else bitmap
        FileOutputStream(file).use { hasil.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    }
}
