@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.presentation.screen

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.OpResult
import com.edupinjam.app.domain.Role
import com.edupinjam.app.presentation.viewmodel.ProfilViewModel
import com.edupinjam.app.presentation.viewmodel.RiwayatViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.AvatarImage
import com.edupinjam.app.ui.components.ConfirmDialog
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTextField
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.EmptyState
import com.edupinjam.app.ui.components.FotoPickerButtons
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.components.SecondaryButton
import com.edupinjam.app.ui.components.SectionTitle
import com.edupinjam.app.ui.theme.GreenOk
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.White
import com.edupinjam.app.utils.BackupUtils

/** ViewModel profil dibuat per pengguna */
@Composable
private fun rememberProfilVm(userId: Long): ProfilViewModel {
    val app = rememberApp()
    return viewModel(
        key = "profil_$userId",
        factory = vmFactory { ProfilViewModel(app.repository, app.session, userId) }
    )
}

/** Satu baris menu pada layar profil */
@Composable
private fun MenuItem(ikon: ImageVector, label: String, onClick: () -> Unit, warna: androidx.compose.ui.graphics.Color = SkyBlue) {
    EduCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(ikon, contentDescription = null, tint = warna)
            Spacer(Modifier.width(14.dp))
            Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = warna, modifier = Modifier.size(18.dp))
        }
    }
}

/** Tab Profil: siswa melihat statistik dan riwayat, admin melihat menu pengelolaan */
@Composable
fun ProfilScreen(
    user: UserEntity,
    onEdit: () -> Unit,
    onGantiPassword: () -> Unit,
    onKelolaPetugas: () -> Unit,
    onPengaturan: () -> Unit,
    onLaporan: () -> Unit
) {
    val vm = rememberProfilVm(user.id)
    val app = rememberApp()
    val total by vm.totalPinjam.collectAsStateWithLifecycle()
    val profil by vm.user.collectAsStateWithLifecycle()
    val u = profil ?: user
    var konfirmasiKeluar by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Profil")
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            EduCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    AvatarImage(u.fotoPath, u.nama, 88.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(u.nama, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(Role.label(u.role), color = SkyBlue, fontWeight = FontWeight.SemiBold)
                    if (u.role == Role.SISWA) {
                        Spacer(Modifier.height(6.dp))
                        Text("NIS: ${u.nis}", fontSize = 13.sp)
                        Text("Kelas: ${u.kelas}", fontSize = 13.sp)
                        Text("No HP: ${u.noHp}", fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$total", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = SkyBlue)
                        Text("Total Pinjam", fontSize = 12.sp)
                    } else {
                        Text("Username: ${u.username}", fontSize = 13.sp)
                    }
                }
            }

            MenuItem(Icons.Filled.Edit, "Ubah Profil", onEdit)
            if (u.role == Role.ADMIN) MenuItem(Icons.Filled.Group, "Kelola Akun Petugas", onKelolaPetugas)
            if (Role.isStaff(u.role)) MenuItem(Icons.Filled.Assessment, "Laporan Bulanan", onLaporan)
            MenuItem(Icons.Filled.Lock, "Ganti Password", onGantiPassword)
            MenuItem(Icons.Filled.Settings, "Pengaturan", onPengaturan)
            MenuItem(Icons.AutoMirrored.Filled.Logout, "Keluar", { konfirmasiKeluar = true }, RedBad)

            if (u.role == Role.SISWA) {
                SectionTitle("Riwayat Peminjaman Saya")
                val rv: RiwayatViewModel = viewModel(
                    key = "profil_riwayat_${u.id}",
                    factory = vmFactory { RiwayatViewModel(app.repository, u.id) }
                )
                val daftar by rv.daftar.collectAsStateWithLifecycle()
                if (daftar.isEmpty()) EmptyState("Belum ada riwayat peminjaman")
                daftar.forEach { PeminjamanItem(it, tampilkanSiswa = false) }
            }
        }
    }

    if (konfirmasiKeluar) {
        ConfirmDialog(
            judul = "Keluar", pesan = "Yakin ingin keluar dari akun ini?", teksYa = "Keluar",
            onYa = { konfirmasiKeluar = false; vm.logout() },
            onBatal = { konfirmasiKeluar = false }
        )
    }
}

/** Ubah nama, kelas, no HP, dan foto profil */
@Composable
fun EditProfilScreen(user: UserEntity, onBack: () -> Unit) {
    val vm = rememberProfilVm(user.id)
    val context = LocalContext.current
    var nama by remember { mutableStateOf(user.nama) }
    var kelas by remember { mutableStateOf(user.kelas) }
    var noHp by remember { mutableStateOf(user.noHp) }
    var foto by remember { mutableStateOf(user.fotoPath) }
    var error by remember { mutableStateOf<String?>(null) }
    val siswa = user.role == Role.SISWA

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Ubah Profil", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AvatarImage(foto, nama, 110.dp) }
            FotoPickerButtons(prefix = "profil", onFoto = { foto = it })
            EduTextField(nama, { nama = it }, "Nama")
            if (siswa) {
                EduTextField(user.nis, {}, "NIS", enabled = false)
                EduTextField(kelas, { kelas = it }, "Kelas")
                EduTextField(noHp, { noHp = it.filter { c -> c.isDigit() } }, "No HP", keyboardType = KeyboardType.Phone)
            }
            error?.let { Text(it, color = RedBad, fontSize = 13.sp) }
            PrimaryButton("Simpan", modifier = Modifier.fillMaxWidth(), onClick = {
                vm.updateProfil(nama, kelas, noHp, foto) { hasil ->
                    when (hasil) {
                        is OpResult.Gagal -> error = hasil.pesan
                        is OpResult.Sukses -> {
                            Toast.makeText(context, "Profil diperbarui", Toast.LENGTH_SHORT).show()
                            onBack()
                        }
                    }
                }
            })
        }
    }
}

/** Ganti password akun yang sedang login */
@Composable
fun GantiPasswordScreen(user: UserEntity, onBack: () -> Unit) {
    val vm = rememberProfilVm(user.id)
    val context = LocalContext.current
    var lama by remember { mutableStateOf("") }
    var baru by remember { mutableStateOf("") }
    var ulang by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Ganti Password", onBack = onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            EduTextField(lama, { lama = it }, "Password Lama", password = true)
            EduTextField(baru, { baru = it }, "Password Baru (min. 6 karakter)", password = true)
            EduTextField(ulang, { ulang = it }, "Ulangi Password Baru", password = true)
            error?.let { Text(it, color = RedBad, fontSize = 13.sp) }
            PrimaryButton("Simpan Password", modifier = Modifier.fillMaxWidth(), onClick = {
                if (baru != ulang) {
                    error = "Konfirmasi password tidak sama"
                } else {
                    vm.gantiPassword(lama, baru) { hasil ->
                        when (hasil) {
                            is OpResult.Gagal -> error = hasil.pesan
                            is OpResult.Sukses -> {
                                Toast.makeText(context, "Password berhasil diganti", Toast.LENGTH_SHORT).show()
                                onBack()
                            }
                        }
                    }
                }
            })
        }
    }
}

/** Admin mengelola akun petugas: tambah dan hapus */
@Composable
fun KelolaPetugasScreen(user: UserEntity, onBack: () -> Unit) {
    val vm = rememberProfilVm(user.id)
    val daftar by vm.daftarPetugas.collectAsStateWithLifecycle()
    var dialogTambah by remember { mutableStateOf(false) }
    var hapus by remember { mutableStateOf<UserEntity?>(null) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Kelola Akun Petugas", onBack = onBack, actions = {
            IconButton(onClick = { dialogTambah = true }) {
                Icon(Icons.Filled.PersonAdd, contentDescription = "Tambah petugas")
            }
        })
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (daftar.isEmpty()) EmptyState("Belum ada akun petugas")
            daftar.forEach { p ->
                EduCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Person, contentDescription = null, tint = SkyBlue)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.nama, fontWeight = FontWeight.Bold)
                            Text("Username: ${p.username}", fontSize = 12.sp)
                        }
                        IconButton(onClick = { hapus = p }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = RedBad)
                        }
                    }
                }
            }
            PrimaryButton("Tambah Petugas", icon = Icons.Filled.PersonAdd, modifier = Modifier.fillMaxWidth(), onClick = { dialogTambah = true })
        }
    }

    if (dialogTambah) {
        var nama by remember { mutableStateOf("") }
        var username by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { dialogTambah = false },
            title = { Text("Tambah Petugas", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    EduTextField(nama, { nama = it }, "Nama")
                    EduTextField(username, { username = it.trim() }, "Username")
                    EduTextField(password, { password = it }, "Password (min. 6 karakter)", password = true)
                    error?.let { Text(it, color = RedBad, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.tambahPetugas(nama, username, password) { hasil ->
                        when (hasil) {
                            is OpResult.Gagal -> error = hasil.pesan
                            is OpResult.Sukses -> dialogTambah = false
                        }
                    }
                }) { Text("Simpan", color = SkyBlue, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dialogTambah = false }) { Text("Batal") } },
            shape = RoundedCornerShape(16.dp)
        )
    }

    hapus?.let { p ->
        ConfirmDialog(
            judul = "Hapus Petugas", pesan = "Hapus akun ${p.nama}?", teksYa = "Hapus",
            onYa = { vm.hapusPetugas(p); hapus = null },
            onBatal = { hapus = null }
        )
    }
}

/** Baris pengaturan dengan saklar */
@Composable
private fun SwitchRow(judul: String, sub: String, nilai: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(judul, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = nilai, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = SkyBlue, checkedThumbColor = White)
        )
    }
}

/** Pengaturan: tema, bahasa, pengingat, backup dan restore data */
@Composable
fun PengaturanScreen(user: UserEntity, onBack: () -> Unit) {
    val vm = rememberProfilVm(user.id)
    val app = rememberApp()
    val context = LocalContext.current
    val gelap by vm.modeGelap.collectAsStateWithLifecycle()
    val pengingat by vm.pengingat.collectAsStateWithLifecycle()
    var konfirmasiRestore by remember { mutableStateOf<android.net.Uri?>(null) }
    var restoreSelesai by remember { mutableStateOf(false) }

    val izinNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { diberi ->
        if (!diberi) Toast.makeText(context, "Izin notifikasi ditolak, pengingat tidak akan tampil", Toast.LENGTH_LONG).show()
    }
    val pilihFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) konfirmasiRestore = uri
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Pengaturan", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            EduCard(Modifier.fillMaxWidth()) {
                SwitchRow(
                    "Mode Gelap", if (gelap) "Tema gelap (biru malam) aktif" else "Tema terang aktif",
                    gelap, { vm.setModeGelap(it) }
                )
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Bahasa", fontWeight = FontWeight.SemiBold)
                        Text("Bahasa Indonesia", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("Aktif", color = GreenOk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            EduCard(Modifier.fillMaxWidth()) {
                SwitchRow(
                    "Pengingat H-1", "Notifikasi 1 hari sebelum jatuh tempo pengembalian",
                    pengingat
                ) { aktif ->
                    vm.setPengingat(aktif)
                    if (aktif && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        izinNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            if (user.role == Role.ADMIN) {
                EduCard(Modifier.fillMaxWidth()) {
                    Text("Backup & Restore Data", fontWeight = FontWeight.Bold)
                    Text(
                        "Simpan salinan database ke Drive/WhatsApp atau pulihkan dari file backup (.db).",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PrimaryButton("Backup", modifier = Modifier.weight(1f), onClick = {
                            try {
                                BackupUtils.bagikan(context, BackupUtils.buatBackup(context, app.database))
                            } catch (e: Exception) {
                                Toast.makeText(context, "Backup gagal", Toast.LENGTH_SHORT).show()
                            }
                        })
                        SecondaryButton("Restore", modifier = Modifier.weight(1f), onClick = {
                            pilihFile.launch(arrayOf("*/*"))
                        })
                    }
                }
            }

            EduCard(Modifier.fillMaxWidth()) {
                Text("EDU-PINJAM v1.0", fontWeight = FontWeight.Bold)
                Text("Aplikasi simpan pinjam inventaris perlengkapan sekolah.", fontSize = 12.sp)
                Text("Denda keterlambatan: Rp 1.000 per hari.", fontSize = 12.sp)
            }
        }
    }

    konfirmasiRestore?.let { uri ->
        ConfirmDialog(
            judul = "Restore Data",
            pesan = "Data saat ini akan diganti dengan isi file backup. Aplikasi akan ditutup setelahnya. Lanjutkan?",
            teksYa = "Restore",
            onYa = {
                konfirmasiRestore = null
                if (BackupUtils.restore(context, uri)) restoreSelesai = true
                else Toast.makeText(context, "File backup tidak valid", Toast.LENGTH_LONG).show()
            },
            onBatal = { konfirmasiRestore = null }
        )
    }

    if (restoreSelesai) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Restore Berhasil", fontWeight = FontWeight.Bold) },
            text = { Text("Aplikasi akan ditutup. Buka kembali EDU-PINJAM untuk memakai data hasil restore.") },
            confirmButton = {
                TextButton(onClick = { android.os.Process.killProcess(android.os.Process.myPid()) }) {
                    Text("Tutup Aplikasi", color = SkyBlue, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
