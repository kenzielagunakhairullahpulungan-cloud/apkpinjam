package com.edupinjam.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "edupinjam_prefs")

/** Sesi login dan pengaturan aplikasi disimpan dengan DataStore */
data class SesiLogin(val userId: Long, val role: String)

class SessionManager(private val context: Context) {

    private object Keys {
        val USER_ID = longPreferencesKey("user_id")
        val ROLE = stringPreferencesKey("role")
        val MODE_GELAP = booleanPreferencesKey("mode_gelap")
        val PENGINGAT = booleanPreferencesKey("pengingat_aktif")
    }

    /** Sesi aktif, null jika belum login */
    val sesi: Flow<SesiLogin?> = context.dataStore.data.map { p: Preferences ->
        val id = p[Keys.USER_ID]
        val role = p[Keys.ROLE]
        if (id != null && role != null) SesiLogin(id, role) else null
    }

    val modeGelap: Flow<Boolean> = context.dataStore.data.map { it[Keys.MODE_GELAP] ?: false }

    val pengingatAktif: Flow<Boolean> = context.dataStore.data.map { it[Keys.PENGINGAT] ?: true }

    suspend fun simpanSesi(userId: Long, role: String) {
        context.dataStore.edit {
            it[Keys.USER_ID] = userId
            it[Keys.ROLE] = role
        }
    }

    suspend fun hapusSesi() {
        context.dataStore.edit {
            it.remove(Keys.USER_ID)
            it.remove(Keys.ROLE)
        }
    }

    suspend fun setModeGelap(aktif: Boolean) {
        context.dataStore.edit { it[Keys.MODE_GELAP] = aktif }
    }

    suspend fun setPengingat(aktif: Boolean) {
        context.dataStore.edit { it[Keys.PENGINGAT] = aktif }
    }
}
