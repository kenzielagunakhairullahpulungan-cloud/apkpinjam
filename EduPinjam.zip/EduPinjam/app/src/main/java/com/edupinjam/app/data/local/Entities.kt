package com.edupinjam.app.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Tabel pengguna: admin, petugas, dan siswa. Username siswa = NIS. */
@Entity(tableName = "users", indices = [Index(value = ["username"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nama: String,
    val username: String,
    val passwordHash: String,
    val role: String,
    val nis: String = "",
    val kelas: String = "",
    val noHp: String = "",
    val fotoPath: String? = null
)

/** Tabel inventaris barang */
@Entity(tableName = "barang", indices = [Index(value = ["kode"], unique = true)])
data class BarangEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nama: String,
    val kategori: String,
    val kode: String,
    val stokTotal: Int,
    val stokTersedia: Int,
    val kondisi: String,
    val fotoPath: String? = null,
    val lokasiRak: String = ""
)

/** Tabel transaksi peminjaman */
@Entity(
    tableName = "peminjaman",
    indices = [Index("userId"), Index("barangId"), Index("status")]
)
data class PeminjamanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val barangId: Long,
    val jumlah: Int,
    val tanggalPinjam: Long,
    /** Batas jatuh tempo, disimpan sebagai akhir hari (23:59:59) */
    val tanggalJatuhTempo: Long,
    val keperluan: String,
    val status: String,
    val tanggalKembali: Long? = null,
    val fotoKembali: String? = null,
    val denda: Long = 0,
    val kondisiKembali: String? = null
)

/** Hasil join peminjaman + nama siswa + data barang (untuk ditampilkan di UI) */
data class PeminjamanDetail(
    @Embedded val peminjaman: PeminjamanEntity,
    val namaSiswa: String,
    val nisSiswa: String,
    val namaBarang: String,
    val kodeBarang: String,
    val fotoBarang: String?
)
