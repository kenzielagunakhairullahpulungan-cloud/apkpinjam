package com.edupinjam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.presentation.navigation.AuthNav
import com.edupinjam.app.presentation.navigation.MainNav
import com.edupinjam.app.presentation.screen.SplashScreen
import com.edupinjam.app.presentation.viewmodel.AuthState
import com.edupinjam.app.presentation.viewmodel.AuthViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.theme.EduPinjamTheme

/** Activity tunggal: seluruh UI dibangun dengan Jetpack Compose */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EduPinjamRoot() }
    }
}

/** Akar aplikasi: memilih Splash, Login, atau layar utama berdasarkan sesi DataStore */
@Composable
fun EduPinjamRoot() {
    val app = rememberApp()
    val authVm: AuthViewModel = viewModel(factory = vmFactory { AuthViewModel(app.repository, app.session) })
    val state by authVm.state.collectAsStateWithLifecycle()
    val modeGelap by app.session.modeGelap.collectAsStateWithLifecycle(initialValue = false)

    EduPinjamTheme(modeGelap = modeGelap) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (val s = state) {
                is AuthState.Memuat -> SplashScreen()
                is AuthState.Keluar -> AuthNav(authVm)
                is AuthState.Masuk -> MainNav(s.user)
            }
        }
    }
}
