@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.data.local.BarangEntity
import com.edupinjam.app.domain.Kategori
import com.edupinjam.app.domain.Kondisi
import com.edupinjam.app.domain.OpResult
import com.edupinjam.app.presentation.viewmodel.BarangDetailViewModel
import com.edupinjam.app.presentation.viewmodel.InventarisViewModel
import com.edupinjam.app.presentation.viewmodel.UrutBarang
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.BarangImage
import com.edupinjam.app.ui.components.ConfirmDialog
import com.edupinjam.app.ui.components.DropdownField
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTextField
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.EmptyState
import com.edupinjam.app.ui.components.FotoPickerButtons
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.components.QrImage
import com.edupinjam.app.ui.components.SecondaryButton
import com.edupinjam.app.ui.components.SectionTitle
import com.edupinjam.app.ui.components.StokBadge
import com.edupinjam.app.ui.components.stokColor
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.White

/** Daftar inventaris: search, filter kategori, sort A-Z dan stok */
@Composable
fun InventarisScreen(
    adalahStaf: Boolean,
    onDetail: (Long) -> Unit,
    onTambah: () -> Unit
) {
    val app = rememberApp()
    val vm: InventarisViewModel = viewModel(factory = vmFactory { InventarisViewModel(app.repository) })
    val daftar by vm.barang.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val kategori by vm.kategori.collectAsStateWithLifecycle()
    val urut by vm.urut.collectAsStateWithLifecycle()
    var menuUrut by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Inventaris", actions = {
            Box {
                IconButton(onClick = { menuUrut = true }) {
                    Icon(Icons.Filled.Sort, contentDescription = "Urutkan")
                }
                DropdownMenu(expanded = menuUrut, onDismissRequest = { menuUrut = false }) {
                    UrutBarang.values().forEach { u ->
                        DropdownMenuItem(
                            text = {
                                Text(u.label, fontWeight = if (u == urut) FontWeight.Bold else FontWeight.Normal)
                            },
                            onClick = { vm.urut.value = u; menuUrut = false }
                        )
                    }
                }
            }
        })
        Box(Modifier.weight(1f)) {
            Column(Modifier.fillMaxSize()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { vm.query.value = it },
                    placeholder = { Text("Cari nama, kode, atau rak...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = SkyBlue) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = kategori == null, onClick = { vm.kategori.value = null },
                            label = { Text("Semua") }, shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = SkyBlue, selectedLabelColor = White)
                        )
                    }
                    items(Kategori.semua) { k ->
                        FilterChip(
                            selected = kategori == k, onClick = { vm.kategori.value = k },
                            label = { Text(k) }, shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = SkyBlue, selectedLabelColor = White)
                        )
                    }
                }
                Text(
                    "${daftar.size} barang - urut: ${urut.label}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                if (daftar.isEmpty()) {
                    EmptyState("Barang tidak ditemukan")
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(daftar, key = { it.id }) { b -> BarangCard(b, onClick = { onDetail(b.id) }) }
                    }
                }
            }
            if (adalahStaf) {
                FloatingActionButton(
                    onClick = onTambah,
                    containerColor = SkyBlue, contentColor = White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) { Icon(Icons.Filled.Add, contentDescription = "Tambah barang") }
            }
        }
    }
}

/** Form tambah/ubah barang. [barangId] null berarti barang baru */
@Composable
fun BarangFormScreen(barangId: Long?, onSelesai: () -> Unit, onBack: () -> Unit) {
    val app = rememberApp()
    val vm: InventarisViewModel = viewModel(factory = vmFactory { InventarisViewModel(app.repository) })

    var nama by remember { mutableStateOf("") }
    var kategori by remember { mutableStateOf(Kategori.semua.first()) }
    var kode by remember { mutableStateOf("") }
    var stok by remember { mutableStateOf("1") }
    var kondisi by remember { mutableStateOf(Kondisi.BAIK) }
    var rak by remember { mutableStateOf("") }
    var foto by remember { mutableStateOf<String?>(null) }
    var stokTersediaLama by remember { mutableStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }

    // Muat data lama (mode ubah) atau buat kode baru (mode tambah)
    LaunchedEffect(barangId) {
        if (barangId != null) {
            vm.ambil(barangId)?.let {
                nama = it.nama; kategori = it.kategori; kode = it.kode
                stok = it.stokTotal.toString(); kondisi = it.kondisi
                rak = it.lokasiRak; foto = it.fotoPath; stokTersediaLama = it.stokTersedia
            }
        } else {
            kode = vm.kodeBerikutnya()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar(if (barangId == null) "Tambah Barang" else "Ubah Barang", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                BarangImage(foto, ukuran = 140.dp)
            }
            FotoPickerButtons(prefix = "barang", onFoto = { foto = it })

            EduTextField(nama, { nama = it }, "Nama Barang")
            DropdownField("Kategori", Kategori.semua, kategori, { kategori = Kategori.semua[it] })
            EduTextField(kode, { kode = it.uppercase() }, "Kode Barang")
            EduTextField(
                stok, { stok = it.filter { c -> c.isDigit() }.take(5) }, "Jumlah Stok",
                keyboardType = KeyboardType.Number
            )
            DropdownField("Kondisi", Kondisi.semua, kondisi, { kondisi = Kondisi.semua[it] })
            EduTextField(rak, { rak = it }, "Lokasi Rak")

            if (kode.isNotBlank()) {
                EduCard(Modifier.fillMaxWidth()) {
                    Text("Pratinjau QR Code", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { QrImage(kode, 150.dp) }
                    Text(
                        "QR dibuat otomatis dari Kode Barang", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            error?.let { Text(it, color = RedBad, fontSize = 13.sp) }

            PrimaryButton(
                text = "Simpan",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val jumlah = stok.toIntOrNull()
                    if (jumlah == null) {
                        error = "Jumlah stok harus berupa angka"
                    } else {
                        val b = BarangEntity(
                            id = barangId ?: 0, nama = nama, kategori = kategori, kode = kode,
                            stokTotal = jumlah, stokTersedia = stokTersediaLama,
                            kondisi = kondisi, fotoPath = foto, lokasiRak = rak
                        )
                        vm.simpan(b) { hasil ->
                            when (hasil) {
                                is OpResult.Gagal -> error = hasil.pesan
                                is OpResult.Sukses -> onSelesai()
                            }
                        }
                    }
                }
            )
        }
    }
}

/** Baris informasi label: nilai */
@Composable
private fun InfoRow(label: String, nilai: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, Modifier.width(110.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(nilai, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Detail barang: foto, stok, QR, riwayat peminjaman barang tersebut */
@Composable
fun BarangDetailScreen(
    barangId: Long,
    adalahStaf: Boolean,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onPinjam: (Long) -> Unit
) {
    val app = rememberApp()
    val vm: BarangDetailViewModel = viewModel(
        key = "detail_$barangId", factory = vmFactory { BarangDetailViewModel(app.repository, barangId) }
    )
    val inv: InventarisViewModel = viewModel(factory = vmFactory { InventarisViewModel(app.repository) })
    val barang by vm.barang.collectAsStateWithLifecycle()
    val riwayat by vm.riwayat.collectAsStateWithLifecycle()
    var konfirmasiHapus by remember { mutableStateOf(false) }
    var pesanError by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Detail Barang", onBack = onBack, actions = {
            if (adalahStaf && barang != null) {
                IconButton(onClick = { onEdit(barangId) }) { Icon(Icons.Filled.Edit, contentDescription = "Ubah") }
                IconButton(onClick = { konfirmasiHapus = true }) { Icon(Icons.Filled.Delete, contentDescription = "Hapus") }
            }
        })
        val b = barang
        if (b == null) {
            EmptyState("Barang tidak ditemukan")
        } else {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    BarangImage(b.fotoPath, ukuran = 200.dp)
                }
                Text(b.nama, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Tersedia ${b.stokTersedia} dari ${b.stokTotal}",
                        color = stokColor(b.stokTersedia), fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(8.dp))
                    StokBadge(b.stokTersedia)
                }
                EduCard(Modifier.fillMaxWidth()) {
                    InfoRow("Kode", b.kode)
                    InfoRow("Kategori", b.kategori)
                    InfoRow("Kondisi", b.kondisi)
                    InfoRow("Lokasi Rak", b.lokasiRak.ifBlank { "-" })
                }
                EduCard(Modifier.fillMaxWidth()) {
                    Text("QR Code Barang", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { QrImage(b.kode, 180.dp) }
                    Text(
                        "Scan QR ini untuk pinjam atau kembalikan lebih cepat", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                PrimaryButton(
                    text = if (b.stokTersedia > 0) "Pinjam Barang Ini" else "Stok Habis",
                    icon = Icons.Filled.SwapHoriz,
                    enabled = b.stokTersedia > 0,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onPinjam(b.id) }
                )
                pesanError?.let { Text(it, color = RedBad, fontSize = 13.sp) }

                SectionTitle("Riwayat Peminjaman")
                if (riwayat.isEmpty()) EmptyState("Belum pernah dipinjam")
                riwayat.forEach { PeminjamanItem(it) }
            }
        }
    }

    if (konfirmasiHapus) {
        ConfirmDialog(
            judul = "Hapus Barang",
            pesan = "Hapus ${barang?.nama} dari inventaris? Tindakan ini tidak bisa dibatalkan.",
            teksYa = "Hapus",
            onYa = {
                konfirmasiHapus = false
                inv.hapus(barangId) { hasil ->
                    when (hasil) {
                        is OpResult.Gagal -> pesanError = hasil.pesan
                        is OpResult.Sukses -> onBack()
                    }
                }
            },
            onBatal = { konfirmasiHapus = false }
        )
    }
}
