@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.Denda
import com.edupinjam.app.domain.Role
import com.edupinjam.app.presentation.viewmodel.KembalikanViewModel
import com.edupinjam.app.presentation.viewmodel.PinjamViewModel
import com.edupinjam.app.presentation.viewmodel.RiwayatViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.BarangImage
import com.edupinjam.app.ui.components.DateField
import com.edupinjam.app.ui.components.DropdownField
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTextField
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.EmptyState
import com.edupinjam.app.ui.components.FotoPickerButtons
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.components.StokBadge
import com.edupinjam.app.ui.components.stokColor
import com.edupinjam.app.ui.theme.GreenOk
import com.edupinjam.app.ui.theme.GreenOkBg
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.RedBadBg
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.utils.RupiahFormat

/** Tab Pinjam: form peminjaman dan daftar barang yang sedang dipinjam */
@Composable
fun PinjamScreen(user: UserEntity, barangAwal: Long?, onKembalikan: (Long) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val staf = Role.isStaff(user.role)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Pinjam Barang")
        TabRow(
            selectedTabIndex = tab,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = SkyBlue,
            indicator = { pos -> TabRowDefaults.Indicator(Modifier.tabIndicatorOffset(pos[tab]), color = SkyBlue) }
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Form Pinjam") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Sedang Dipinjam") })
        }
        if (tab == 0) FormPinjam(user, barangAwal) else DaftarAktif(user, staf, onKembalikan)
    }
}

/** Form pinjam dengan validasi stok otomatis */
@Composable
private fun FormPinjam(user: UserEntity, barangAwal: Long?) {
    val app = rememberApp()
    val siswaTetap = if (user.role == Role.SISWA) user.id else null
    val vm: PinjamViewModel = viewModel(
        key = "pinjam_${user.id}", factory = vmFactory { PinjamViewModel(app.repository, siswaTetap) }
    )
    val daftarSiswa by vm.daftarSiswa.collectAsStateWithLifecycle()
    val daftarBarang by vm.daftarBarang.collectAsStateWithLifecycle()
    val siswaId by vm.siswaId.collectAsStateWithLifecycle()
    val barangId by vm.barangId.collectAsStateWithLifecycle()
    val jumlah by vm.jumlah.collectAsStateWithLifecycle()
    val tglPinjam by vm.tglPinjam.collectAsStateWithLifecycle()
    val tglKembali by vm.tglKembali.collectAsStateWithLifecycle()
    val keperluan by vm.keperluan.collectAsStateWithLifecycle()
    val hasil by vm.hasil.collectAsStateWithLifecycle()
    val proses by vm.sedangProses.collectAsStateWithLifecycle()
    val barang by vm.barangTerpilih.collectAsStateWithLifecycle()

    // Barang terisi otomatis bila datang dari detail barang atau scan QR
    LaunchedEffect(barangAwal) {
        if (barangAwal != null && barangAwal > 0) vm.barangId.value = barangAwal
    }

    val namaSiswaTerpilih = daftarSiswa.firstOrNull { it.id == siswaId }
        ?.let { "${it.nama} (${it.nis})" } ?: ""
    val labelBarang = daftarBarang.map { "${it.nama} (${it.kode})" + if (it.stokTersedia <= 0) " - Habis" else "" }
    val namaBarangTerpilih = barang?.let { "${it.nama} (${it.kode})" } ?: ""
    val stokHabis = barang?.let { it.stokTersedia <= 0 } ?: false

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (siswaTetap != null) {
            EduTextField("${user.nama} (${user.nis})", {}, "Peminjam", enabled = false)
        } else {
            DropdownField(
                "Pilih Siswa", daftarSiswa.map { "${it.nama} (${it.nis})" }, namaSiswaTerpilih,
                { vm.siswaId.value = daftarSiswa[it].id }
            )
        }

        DropdownField("Pilih Barang", labelBarang, namaBarangTerpilih, { vm.barangId.value = daftarBarang[it].id })

        barang?.let { b ->
            EduCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BarangImage(b.fotoPath, ukuran = 56.dp)
                    Spacer(Modifier.padding(6.dp))
                    Column {
                        Text(b.nama, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Stok tersedia: ${b.stokTersedia}", color = stokColor(b.stokTersedia),
                                fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                            )
                            Spacer(Modifier.padding(4.dp))
                            StokBadge(b.stokTersedia)
                        }
                        Text("Kondisi: ${b.kondisi}", fontSize = 12.sp)
                    }
                }
            }
        }
        if (stokHabis) {
            Text("Stok habis, barang ini tidak bisa dipinjam.", color = RedBad, fontSize = 13.sp)
        }

        EduTextField(jumlah, { vm.ubahJumlah(it) }, "Jumlah", keyboardType = KeyboardType.Number)
        DateField("Tanggal Pinjam", tglPinjam, { vm.ubahTglPinjam(it) })
        DateField("Tanggal Kembali", tglKembali, { vm.tglKembali.value = it })
        EduTextField(keperluan, { vm.keperluan.value = it }, "Keperluan", singleLine = false, minLines = 2)

        Text(
            "Denda keterlambatan ${RupiahFormat.format(Denda.PER_HARI)} per hari.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        hasil?.let { (ok, teks) ->
            EduCard(Modifier.fillMaxWidth(), container = if (ok) GreenOkBg else RedBadBg) {
                Text(teks, color = if (ok) GreenOk else RedBad, fontWeight = FontWeight.SemiBold)
            }
        }

        PrimaryButton(
            text = if (proses) "Memproses..." else "Pinjam",
            icon = Icons.Filled.SwapHoriz,
            enabled = !proses && !stokHabis,
            modifier = Modifier.fillMaxWidth(),
            onClick = { vm.kirim() }
        )
    }
}

/** Daftar barang yang belum dikembalikan; staf bisa menekan Kembalikan */
@Composable
private fun DaftarAktif(user: UserEntity, staf: Boolean, onKembalikan: (Long) -> Unit) {
    val app = rememberApp()
    val vm: RiwayatViewModel = viewModel(
        key = "aktif_${user.id}",
        factory = vmFactory { RiwayatViewModel(app.repository, if (staf) null else user.id) }
    )
    val aktif by vm.aktif.collectAsStateWithLifecycle()

    if (aktif.isEmpty()) {
        EmptyState("Tidak ada barang yang sedang dipinjam")
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(aktif, key = { it.peminjaman.id }) { d ->
                PeminjamanItem(d, tampilkanSiswa = staf, aksi = if (staf) {
                    {
                        PrimaryButton(
                            "Kembalikan", onClick = { onKembalikan(d.peminjaman.id) },
                            icon = Icons.Filled.CheckCircle
                        )
                    }
                } else null)
            }
        }
    }
}

/** Layar pengembalian: foto kondisi barang, tanda rusak, dan hitung denda */
@Composable
fun KembalikanScreen(peminjamanId: Long, onSelesai: () -> Unit, onBack: () -> Unit) {
    val app = rememberApp()
    val vm: KembalikanViewModel = viewModel(
        key = "kembali_$peminjamanId", factory = vmFactory { KembalikanViewModel(app.repository, peminjamanId) }
    )
    val detail by vm.detail.collectAsStateWithLifecycle()
    val foto by vm.fotoPath.collectAsStateWithLifecycle()
    val rusak by vm.rusak.collectAsStateWithLifecycle()
    val proses by vm.sedangProses.collectAsStateWithLifecycle()
    val error by vm.pesanError.collectAsStateWithLifecycle()
    var dendaAkhir by remember { mutableStateOf<Long?>(null) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Kembalikan Barang", onBack = onBack)
        val d = detail
        if (d == null) {
            EmptyState("Memuat data peminjaman...")
        } else {
            val sekarang = System.currentTimeMillis()
            val hariTerlambat = Denda.hariTerlambat(d.peminjaman.tanggalJatuhTempo, sekarang)
            val dendaSementara = Denda.hitung(d.peminjaman.tanggalJatuhTempo, sekarang)
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PeminjamanItem(d)

                EduCard(Modifier.fillMaxWidth(), container = if (dendaSementara > 0) RedBadBg else GreenOkBg) {
                    Text(
                        if (hariTerlambat > 0) "Terlambat $hariTerlambat hari" else "Tepat waktu",
                        fontWeight = FontWeight.Bold, color = if (hariTerlambat > 0) RedBad else GreenOk
                    )
                    Text(
                        "Denda: ${RupiahFormat.format(dendaSementara)}",
                        fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                        color = if (hariTerlambat > 0) RedBad else GreenOk
                    )
                }

                Text("Foto Kondisi Barang", fontWeight = FontWeight.Bold)
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    BarangImage(foto, ukuran = 180.dp)
                }
                FotoPickerButtons(prefix = "kembali", onFoto = { vm.fotoPath.value = it })

                Row(
                    Modifier.fillMaxWidth().clickable { vm.rusak.value = !rusak },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = rusak, onCheckedChange = { vm.rusak.value = it },
                        colors = CheckboxDefaults.colors(checkedColor = SkyBlue)
                    )
                    Text("Barang dikembalikan dalam keadaan rusak")
                }

                error?.let { Text(it, color = RedBad, fontSize = 13.sp) }

                PrimaryButton(
                    text = if (proses) "Memproses..." else "Konfirmasi Pengembalian",
                    enabled = !proses,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { vm.kembalikan { dendaAkhir = it } }
                )
            }
        }
    }

    dendaAkhir?.let { denda ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Pengembalian Berhasil", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    if (denda > 0) "Stok bertambah otomatis. Denda keterlambatan: ${RupiahFormat.format(denda)}"
                    else "Stok bertambah otomatis. Tidak ada denda."
                )
            },
            confirmButton = {
                TextButton(onClick = { dendaAkhir = null; onSelesai() }) {
                    Text("OK", color = SkyBlue, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
