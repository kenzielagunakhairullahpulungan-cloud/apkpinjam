package com.edupinjam.app.utils

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.edupinjam.app.domain.LaporanBulanan
import java.io.File
import java.io.FileOutputStream

/** Export laporan bulanan ke PDF dan Excel (SpreadsheetML .xls yang langsung terbuka di Excel) */
object ExportUtils {

    private fun folder(context: Context): File = File(context.cacheDir, "laporan").apply { mkdirs() }

    private fun namaFile(l: LaporanBulanan, ext: String) =
        "Laporan_EDU-PINJAM_${l.labelBulan.replace(' ', '_')}.$ext"

    // ------------------------------------------------------------------ PDF

    fun exportPdf(context: Context, l: LaporanBulanan): File {
        val file = File(folder(context), namaFile(l, "pdf"))
        val doc = PdfDocument()
        val lebar = 595
        val tinggi = 842
        val margin = 40f

        val biru = Color.parseColor("#0284C7")
        val teks = Color.parseColor("#0F172A")
        val pJudul = Paint().apply { color = biru; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
        val pSub = Paint().apply { color = teks; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
        val pIsi = Paint().apply { color = teks; textSize = 10.5f; isAntiAlias = true }
        val pGaris = Paint().apply { color = biru; strokeWidth = 1.2f }

        var nomorHalaman = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(lebar, tinggi, nomorHalaman).create())
        var c = page.canvas
        var y = margin + 10f

        // Mulai halaman baru bila ruang habis
        fun pastikanRuang(butuh: Float) {
            if (y + butuh > tinggi - margin) {
                doc.finishPage(page)
                nomorHalaman++
                page = doc.startPage(PdfDocument.PageInfo.Builder(lebar, tinggi, nomorHalaman).create())
                c = page.canvas
                y = margin + 10f
            }
        }

        fun baris(teksBaris: String, paint: Paint = pIsi, tinggiBaris: Float = 16f) {
            pastikanRuang(tinggiBaris)
            c.drawText(teksBaris, margin, y, paint)
            y += tinggiBaris
        }

        c.drawText("EDU-PINJAM", margin, y, pJudul); y += 22f
        baris("Laporan Peminjaman Bulanan - ${l.labelBulan}", pSub, 20f)
        c.drawLine(margin, y - 8f, lebar - margin, y - 8f, pGaris)
        y += 6f

        baris("Total transaksi : ${l.totalTransaksi}")
        baris("Total unit dipinjam : ${l.totalUnit}")
        baris("Total denda : ${RupiahFormat.format(l.totalDenda)}", pIsi, 22f)

        baris("Barang Paling Sering Dipinjam", pSub, 18f)
        if (l.barangPopuler.isEmpty()) baris("- Belum ada data")
        l.barangPopuler.forEachIndexed { i, b -> baris("${i + 1}. ${b.nama} (${b.kode}) - ${b.jumlah}x") }
        y += 8f

        baris("Siswa Paling Aktif Meminjam", pSub, 18f)
        if (l.siswaAktif.isEmpty()) baris("- Belum ada data")
        l.siswaAktif.forEachIndexed { i, s -> baris("${i + 1}. ${s.nama} (NIS ${s.nis}) - ${s.jumlah}x") }
        y += 8f

        baris("Daftar Transaksi", pSub, 18f)
        if (l.transaksi.isEmpty()) baris("- Tidak ada transaksi pada bulan ini")
        l.transaksi.forEach { d ->
            val p = d.peminjaman
            val kiri = "${DateUtils.formatTanggal(p.tanggalPinjam)}  ${d.namaSiswa.take(20)}  " +
                "${d.namaBarang.take(24)} x${p.jumlah}"
            val kanan = "${p.status}" + if (p.denda > 0) "  ${RupiahFormat.format(p.denda)}" else ""
            pastikanRuang(16f)
            c.drawText(kiri, margin, y, pIsi)
            val lebarKanan = pIsi.measureText(kanan)
            c.drawText(kanan, lebar - margin - lebarKanan, y, pIsi)
            y += 16f
        }

        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    // ---------------------------------------------------------------- Excel

    private fun esc(s: String) = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun sel(nilai: String) = "<Cell><Data ss:Type=\"String\">${esc(nilai)}</Data></Cell>"
    private fun selAngka(nilai: Number) = "<Cell><Data ss:Type=\"Number\">$nilai</Data></Cell>"
    private fun selTebal(nilai: String) =
        "<Cell ss:StyleID=\"h\"><Data ss:Type=\"String\">${esc(nilai)}</Data></Cell>"
    private fun row(vararg sels: String) = "<Row>${sels.joinToString("")}</Row>\n"

    fun exportExcel(context: Context, l: LaporanBulanan): File {
        val file = File(folder(context), namaFile(l, "xls"))
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<?mso-application progid=\"Excel.Sheet\"?>\n")
        sb.append(
            "<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" " +
                "xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n"
        )
        sb.append("<Styles><Style ss:ID=\"h\"><Font ss:Bold=\"1\"/><Interior ss:Color=\"#E0F2FE\" ss:Pattern=\"Solid\"/></Style></Styles>\n")

        // Sheet 1: ringkasan
        sb.append("<Worksheet ss:Name=\"Ringkasan\"><Table>\n")
        sb.append(row(selTebal("Laporan EDU-PINJAM"), sel(l.labelBulan)))
        sb.append(row(sel("Total transaksi"), selAngka(l.totalTransaksi)))
        sb.append(row(sel("Total unit dipinjam"), selAngka(l.totalUnit)))
        sb.append(row(sel("Total denda (Rp)"), selAngka(l.totalDenda)))
        sb.append(row(sel("")))
        sb.append(row(selTebal("Barang Paling Sering Dipinjam"), selTebal("Kode"), selTebal("Jumlah")))
        l.barangPopuler.forEach { sb.append(row(sel(it.nama), sel(it.kode), selAngka(it.jumlah))) }
        sb.append(row(sel("")))
        sb.append(row(selTebal("Siswa Paling Aktif"), selTebal("NIS"), selTebal("Jumlah")))
        l.siswaAktif.forEach { sb.append(row(sel(it.nama), sel(it.nis), selAngka(it.jumlah))) }
        sb.append("</Table></Worksheet>\n")

        // Sheet 2: transaksi
        sb.append("<Worksheet ss:Name=\"Transaksi\"><Table>\n")
        sb.append(
            row(
                selTebal("Tanggal Pinjam"), selTebal("Jatuh Tempo"), selTebal("Tanggal Kembali"),
                selTebal("Siswa"), selTebal("NIS"), selTebal("Barang"), selTebal("Jumlah"),
                selTebal("Status"), selTebal("Denda (Rp)"), selTebal("Keperluan")
            )
        )
        l.transaksi.forEach { d ->
            val p = d.peminjaman
            sb.append(
                row(
                    sel(DateUtils.formatTanggal(p.tanggalPinjam)),
                    sel(DateUtils.formatTanggal(p.tanggalJatuhTempo)),
                    sel(p.tanggalKembali?.let { DateUtils.formatTanggal(it) } ?: "-"),
                    sel(d.namaSiswa), sel(d.nisSiswa), sel(d.namaBarang),
                    selAngka(p.jumlah), sel(p.status), selAngka(p.denda), sel(p.keperluan)
                )
            )
        }
        sb.append("</Table></Worksheet>\n</Workbook>")
        file.writeText(sb.toString())
        return file
    }

    /** Bagikan file hasil export lewat chooser Android (simpan ke Drive, kirim WhatsApp, dll) */
    fun bagikan(context: Context, file: File, mime: String) {
        val uri = ImageUtils.uriUntukFile(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan laporan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
