package com.edupinjam.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** Query dasar join peminjaman dengan siswa dan barang (LEFT JOIN agar riwayat tetap ada) */
const val SELECT_DETAIL = """
    SELECT p.*,
           COALESCE(u.nama, '-') AS namaSiswa,
           COALESCE(u.nis, '') AS nisSiswa,
           COALESCE(b.nama, '(Barang dihapus)') AS namaBarang,
           COALESCE(b.kode, '-') AS kodeBarang,
           b.fotoPath AS fotoBarang
    FROM peminjaman p
    LEFT JOIN users u ON u.id = p.userId
    LEFT JOIN barang b ON b.id = p.barangId
"""

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: UserEntity): Long

    @Update
    suspend fun update(user: UserEntity)

    @Delete
    suspend fun delete(user: UserEntity)

    @Query("SELECT * FROM users WHERE username = :username AND passwordHash = :hash LIMIT 1")
    suspend fun login(username: String, hash: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getById(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    fun observeById(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE role = :role ORDER BY nama")
    fun observeByRole(role: String): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int
}

@Dao
interface BarangDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(barang: BarangEntity): Long

    @Update
    suspend fun update(barang: BarangEntity)

    @Query("DELETE FROM barang WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM barang WHERE id = :id")
    suspend fun getById(id: Long): BarangEntity?

    @Query("SELECT * FROM barang WHERE id = :id")
    fun observeById(id: Long): Flow<BarangEntity?>

    @Query("SELECT * FROM barang WHERE kode = :kode LIMIT 1")
    suspend fun getByKode(kode: String): BarangEntity?

    @Query("SELECT * FROM barang ORDER BY nama COLLATE NOCASE")
    fun observeAll(): Flow<List<BarangEntity>>

    @Query("SELECT * FROM barang ORDER BY nama COLLATE NOCASE")
    suspend fun getAll(): List<BarangEntity>

    @Query("SELECT COUNT(*) FROM barang")
    suspend fun count(): Int

    /** Tambah/kurangi stok tersedia (delta negatif saat dipinjam) */
    @Query("UPDATE barang SET stokTersedia = stokTersedia + :delta WHERE id = :id")
    suspend fun adjustStok(id: Long, delta: Int)

    @Query("UPDATE barang SET kondisi = :kondisi WHERE id = :id")
    suspend fun updateKondisi(id: Long, kondisi: String)

    @Query("SELECT COALESCE(SUM(stokTotal), 0) FROM barang")
    fun observeTotalStok(): Flow<Int>

    @Query("SELECT COALESCE(SUM(stokTersedia), 0) FROM barang")
    fun observeTotalTersedia(): Flow<Int>
}

@Dao
interface PeminjamanDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(p: PeminjamanEntity): Long

    @Update
    suspend fun update(p: PeminjamanEntity)

    @Query("SELECT * FROM peminjaman WHERE id = :id")
    suspend fun getById(id: Long): PeminjamanEntity?

    @Query(SELECT_DETAIL + " WHERE p.id = :id")
    suspend fun getDetailById(id: Long): PeminjamanDetail?

    @Query(SELECT_DETAIL + " ORDER BY p.tanggalPinjam DESC, p.id DESC")
    fun observeDetail(): Flow<List<PeminjamanDetail>>

    @Query(SELECT_DETAIL + " ORDER BY p.tanggalPinjam DESC, p.id DESC")
    suspend fun getAllDetail(): List<PeminjamanDetail>

    @Query(SELECT_DETAIL + " WHERE p.userId = :userId ORDER BY p.tanggalPinjam DESC, p.id DESC")
    fun observeDetailByUser(userId: Long): Flow<List<PeminjamanDetail>>

    @Query(SELECT_DETAIL + " WHERE p.barangId = :barangId ORDER BY p.tanggalPinjam DESC, p.id DESC")
    fun observeDetailByBarang(barangId: Long): Flow<List<PeminjamanDetail>>

    /** Peminjaman yang masih aktif (belum kembali), dipakai untuk pengingat */
    @Query(SELECT_DETAIL + " WHERE p.status IN ('Dipinjam', 'Terlambat') ORDER BY p.tanggalJatuhTempo")
    suspend fun getActiveDetail(): List<PeminjamanDetail>

    /** Tandai peminjaman yang sudah lewat jatuh tempo sebagai Terlambat */
    @Query("UPDATE peminjaman SET status = 'Terlambat' WHERE status = 'Dipinjam' AND tanggalJatuhTempo < :now")
    suspend fun markOverdue(now: Long)

    @Query("SELECT COALESCE(SUM(jumlah), 0) FROM peminjaman WHERE status IN ('Dipinjam', 'Terlambat')")
    fun observeJumlahDipinjam(): Flow<Int>

    @Query("SELECT COALESCE(SUM(jumlah), 0) FROM peminjaman WHERE status = 'Terlambat'")
    fun observeJumlahTerlambat(): Flow<Int>

    /** Daftar tanggal pinjam sejak waktu tertentu, dikelompokkan per hari di ViewModel */
    @Query("SELECT tanggalPinjam FROM peminjaman WHERE tanggalPinjam >= :sejak")
    fun observeTanggalPinjamSejak(sejak: Long): Flow<List<Long>>

    @Query("SELECT COALESCE(SUM(jumlah), 0) FROM peminjaman WHERE barangId = :barangId AND status IN ('Dipinjam', 'Terlambat')")
    suspend fun unitAktifByBarang(barangId: Long): Int

    @Query("SELECT COUNT(*) FROM peminjaman WHERE userId = :userId")
    fun observeTotalByUser(userId: Long): Flow<Int>
}
