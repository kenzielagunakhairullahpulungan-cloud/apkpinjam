package com.edupinjam.app.utils

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

/** Pembuat QR Code dari Kode Barang menggunakan ZXing */
object QrUtils {
    fun buatQr(isi: String, ukuran: Int = 512): Bitmap {
        val hints = mapOf(EncodeHintType.MARGIN to 1, EncodeHintType.CHARACTER_SET to "UTF-8")
        val matrix = QRCodeWriter().encode(isi, BarcodeFormat.QR_CODE, ukuran, ukuran, hints)
        val pixels = IntArray(ukuran * ukuran)
        for (y in 0 until ukuran) {
            for (x in 0 until ukuran) {
                // Modul gelap memakai biru tua agar tetap terbaca dan serasi dengan tema
                pixels[y * ukuran + x] = if (matrix.get(x, y)) Color.parseColor("#0F172A") else Color.WHITE
            }
        }
        return Bitmap.createBitmap(pixels, ukuran, ukuran, Bitmap.Config.ARGB_8888)
    }
}
