package com.edupinjam.app.domain

// Satu hari dalam milidetik
const val DAY_MS = 86_400_000L

/** Peran pengguna aplikasi */
object Role {
    const val ADMIN = "ADMIN"
    const val PETUGAS = "PETUGAS"
    const val SISWA = "SISWA"

    fun label(role: String?): String = when (role) {
        ADMIN -> "Admin"
        PETUGAS -> "Petugas"
        else -> "Siswa"
    }

    /** Admin dan Petugas dianggap staf yang boleh mengelola inventaris */
    fun isStaff(role: String?): Boolean = role == ADMIN || role == PETUGAS
}

/** Daftar kategori barang */
object Kategori {
    val semua = listOf("Alat Tulis", "Buku", "Elektronik", "Olahraga", "Lab", "Musik", "Lainnya")
}

/** Kondisi fisik barang */
object Kondisi {
    const val BAIK = "Baik"
    const val RUSAK_RINGAN = "Rusak Ringan"
    const val RUSAK_BERAT = "Rusak Berat"
    val semua = listOf(BAIK, RUSAK_RINGAN, RUSAK_BERAT)
}

/** Status transaksi peminjaman */
object StatusPinjam {
    const val DIPINJAM = "Dipinjam"
    const val DIKEMBALIKAN = "Dikembalikan"
    const val TERLAMBAT = "Terlambat"
    const val RUSAK = "Rusak"

    /** Status yang berarti barang masih berada di tangan peminjam */
    fun aktif(status: String) = status == DIPINJAM || status == TERLAMBAT
}

/** Level indikator stok: hijau, kuning, merah */
enum class StokLevel(val label: String) {
    TERSEDIA("Tersedia"),
    SISA_SEDIKIT("Sisa Sedikit"),
    HABIS("Habis")
}

fun stokLevel(tersedia: Int): StokLevel = when {
    tersedia <= 0 -> StokLevel.HABIS
    tersedia <= 2 -> StokLevel.SISA_SEDIKIT
    else -> StokLevel.TERSEDIA
}

/** Perhitungan keterlambatan dan denda: Rp 1.000 per hari terlambat */
object Denda {
    const val PER_HARI = 1000L

    /** Jumlah hari terlambat; jatuh tempo disimpan sebagai akhir hari (23:59:59) */
    fun hariTerlambat(jatuhTempo: Long, sekarang: Long): Int =
        if (sekarang <= jatuhTempo) 0 else (((sekarang - jatuhTempo) / DAY_MS) + 1).toInt()

    fun hitung(jatuhTempo: Long, sekarang: Long): Long =
        hariTerlambat(jatuhTempo, sekarang) * PER_HARI
}

/** Hasil operasi repository: sukses membawa data, gagal membawa pesan error */
sealed class OpResult<out T> {
    data class Sukses<T>(val data: T) : OpResult<T>()
    data class Gagal(val pesan: String) : OpResult<Nothing>()
}

/** Barang yang paling sering dipinjam (untuk laporan) */
data class BarangPopuler(val nama: String, val kode: String, val jumlah: Int)

/** Siswa paling aktif meminjam (untuk laporan) */
data class SiswaAktif(val nama: String, val nis: String, val jumlah: Int)
