package com.edupinjam.app.data.repository

import androidx.room.withTransaction
import com.edupinjam.app.data.local.AppDatabase
import com.edupinjam.app.data.local.BarangEntity
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.data.local.PeminjamanEntity
import com.edupinjam.app.data.local.SeedData
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.DAY_MS
import com.edupinjam.app.domain.Denda
import com.edupinjam.app.domain.Kondisi
import com.edupinjam.app.domain.OpResult
import com.edupinjam.app.domain.Role
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.utils.DateUtils
import com.edupinjam.app.utils.Security
import kotlinx.coroutines.flow.Flow

/** Repository tunggal: satu pintu akses data untuk semua ViewModel */
class AppRepository(private val db: AppDatabase) {

    private val userDao = db.userDao()
    private val barangDao = db.barangDao()
    private val pinjamDao = db.peminjamanDao()

    // ---------------------------------------------------------------- Seed data

    /** Isi data awal (akun demo, 15 barang, contoh transaksi) saat database masih kosong */
    suspend fun seedIfEmpty() {
        db.withTransaction {
            if (userDao.count() > 0) return@withTransaction
            val userIds = SeedData.users().map { userDao.insert(it) }
            val barangIds = SeedData.barang().map { barangDao.insert(it) }
            val sekarang = System.currentTimeMillis()

            // siswaIdx: 2..4 (siswa), barangIdx: urutan di SeedData.barang()
            suspend fun contoh(
                siswaIdx: Int, barangIdx: Int, jumlah: Int, pinjamHariLalu: Int,
                jatuhTempoHari: Int, kembaliHariLalu: Int?, keperluan: String
            ) {
                val jatuhTempo = DateUtils.endOfDay(sekarang + jatuhTempoHari * DAY_MS)
                val tglKembali = kembaliHariLalu?.let { sekarang - it * DAY_MS }
                val status = when {
                    tglKembali != null -> StatusPinjam.DIKEMBALIKAN
                    jatuhTempo < sekarang -> StatusPinjam.TERLAMBAT
                    else -> StatusPinjam.DIPINJAM
                }
                pinjamDao.insert(
                    PeminjamanEntity(
                        userId = userIds[siswaIdx],
                        barangId = barangIds[barangIdx],
                        jumlah = jumlah,
                        tanggalPinjam = sekarang - pinjamHariLalu * DAY_MS,
                        tanggalJatuhTempo = jatuhTempo,
                        keperluan = keperluan,
                        status = status,
                        tanggalKembali = tglKembali,
                        denda = if (tglKembali != null) Denda.hitung(jatuhTempo, tglKembali) else 0,
                        kondisiKembali = if (tglKembali != null) "Baik" else null
                    )
                )
                if (tglKembali == null) barangDao.adjustStok(barangIds[barangIdx], -jumlah)
            }

            contoh(2, 0, 1, 3, 2, null, "Presentasi kelas")
            contoh(3, 1, 2, 8, -3, null, "Tugas kelompok")
            contoh(4, 2, 1, 5, -2, 2, "Latihan ekstrakurikuler")
            contoh(2, 3, 1, 6, -3, 4, "Praktikum biologi")
            contoh(3, 4, 1, 1, 6, null, "Latihan band")
            contoh(4, 6, 1, 2, 1, null, "Dokumentasi acara")
            contoh(2, 5, 2, 10, -7, 5, "Tugas geografi")
        }
    }

    // --------------------------------------------------------------- Pengguna

    suspend fun login(username: String, password: String): UserEntity? =
        userDao.login(username.trim(), Security.sha256(password))

    suspend fun getUser(id: Long): UserEntity? = userDao.getById(id)

    fun observeUser(id: Long): Flow<UserEntity?> = userDao.observeById(id)

    fun observeSiswa(): Flow<List<UserEntity>> = userDao.observeByRole(Role.SISWA)

    fun observePetugas(): Flow<List<UserEntity>> = userDao.observeByRole(Role.PETUGAS)

    /** Registrasi siswa baru. Username = NIS */
    suspend fun registerSiswa(
        nama: String, nis: String, kelas: String, noHp: String, password: String
    ): OpResult<Long> {
        if (nama.isBlank()) return OpResult.Gagal("Nama wajib diisi")
        if (nis.isBlank() || !nis.all { it.isDigit() }) return OpResult.Gagal("NIS harus berupa angka")
        if (kelas.isBlank()) return OpResult.Gagal("Kelas wajib diisi")
        if (noHp.length < 8 || !noHp.all { it.isDigit() }) return OpResult.Gagal("No HP tidak valid")
        if (password.length < 6) return OpResult.Gagal("Password minimal 6 karakter")
        if (userDao.getByUsername(nis.trim()) != null) return OpResult.Gagal("NIS sudah terdaftar")
        val id = userDao.insert(
            UserEntity(
                nama = nama.trim(), username = nis.trim(),
                passwordHash = Security.sha256(password), role = Role.SISWA,
                nis = nis.trim(), kelas = kelas.trim(), noHp = noHp.trim()
            )
        )
        return OpResult.Sukses(id)
    }

    /** Admin menambah akun petugas */
    suspend fun tambahPetugas(nama: String, username: String, password: String): OpResult<Long> {
        if (nama.isBlank()) return OpResult.Gagal("Nama wajib diisi")
        if (username.length < 3) return OpResult.Gagal("Username minimal 3 karakter")
        if (password.length < 6) return OpResult.Gagal("Password minimal 6 karakter")
        if (userDao.getByUsername(username.trim()) != null) return OpResult.Gagal("Username sudah dipakai")
        val id = userDao.insert(
            UserEntity(
                nama = nama.trim(), username = username.trim(),
                passwordHash = Security.sha256(password), role = Role.PETUGAS
            )
        )
        return OpResult.Sukses(id)
    }

    suspend fun hapusPetugas(user: UserEntity) {
        if (user.role == Role.PETUGAS) userDao.delete(user)
    }

    suspend fun gantiPassword(userId: Long, lama: String, baru: String): OpResult<Unit> {
        val user = userDao.getById(userId) ?: return OpResult.Gagal("Akun tidak ditemukan")
        if (user.passwordHash != Security.sha256(lama)) return OpResult.Gagal("Password lama salah")
        if (baru.length < 6) return OpResult.Gagal("Password baru minimal 6 karakter")
        userDao.update(user.copy(passwordHash = Security.sha256(baru)))
        return OpResult.Sukses(Unit)
    }

    suspend fun updateProfil(
        userId: Long, nama: String, kelas: String, noHp: String, fotoPath: String?
    ): OpResult<Unit> {
        val user = userDao.getById(userId) ?: return OpResult.Gagal("Akun tidak ditemukan")
        if (nama.isBlank()) return OpResult.Gagal("Nama wajib diisi")
        userDao.update(
            user.copy(
                nama = nama.trim(), kelas = kelas.trim(), noHp = noHp.trim(),
                fotoPath = fotoPath ?: user.fotoPath
            )
        )
        return OpResult.Sukses(Unit)
    }

    // ---------------------------------------------------------------- Barang

    fun observeBarang(): Flow<List<BarangEntity>> = barangDao.observeAll()

    fun observeBarang(id: Long): Flow<BarangEntity?> = barangDao.observeById(id)

    suspend fun getBarang(id: Long): BarangEntity? = barangDao.getById(id)

    suspend fun getBarangByKode(kode: String): BarangEntity? = barangDao.getByKode(kode.trim())

    suspend fun getSemuaBarang(): List<BarangEntity> = barangDao.getAll()

    /** Membuat kode barang berikutnya, contoh: EDU-016 */
    suspend fun kodeBerikutnya(): String {
        var n = barangDao.count() + 1
        while (barangDao.getByKode("EDU-%03d".format(n)) != null) n++
        return "EDU-%03d".format(n)
    }

    /** Simpan barang baru (id = 0) atau perbarui yang sudah ada */
    suspend fun simpanBarang(b: BarangEntity): OpResult<Long> {
        if (b.nama.isBlank()) return OpResult.Gagal("Nama barang wajib diisi")
        if (b.kode.isBlank()) return OpResult.Gagal("Kode barang wajib diisi")
        if (b.stokTotal < 0) return OpResult.Gagal("Jumlah stok tidak boleh negatif")
        return db.withTransaction {
            val ada = barangDao.getByKode(b.kode.trim())
            if (ada != null && ada.id != b.id) {
                return@withTransaction OpResult.Gagal("Kode barang sudah dipakai")
            }
            val bersih = b.copy(nama = b.nama.trim(), kode = b.kode.trim(), lokasiRak = b.lokasiRak.trim())
            if (b.id == 0L) {
                OpResult.Sukses(barangDao.insert(bersih.copy(stokTersedia = bersih.stokTotal)))
            } else {
                val dipinjam = pinjamDao.unitAktifByBarang(b.id)
                if (bersih.stokTotal < dipinjam) {
                    return@withTransaction OpResult.Gagal(
                        "Stok total tidak boleh kurang dari jumlah yang sedang dipinjam ($dipinjam)"
                    )
                }
                barangDao.update(bersih.copy(stokTersedia = bersih.stokTotal - dipinjam))
                OpResult.Sukses(b.id)
            }
        }
    }

    suspend fun hapusBarang(id: Long): OpResult<Unit> {
        if (pinjamDao.unitAktifByBarang(id) > 0) {
            return OpResult.Gagal("Barang sedang dipinjam, tidak bisa dihapus")
        }
        barangDao.deleteById(id)
        return OpResult.Sukses(Unit)
    }

    // ----------------------------------------------------------- Peminjaman

    /** Perbarui status Terlambat untuk transaksi yang lewat jatuh tempo */
    suspend fun refreshTerlambat() = pinjamDao.markOverdue(System.currentTimeMillis())

    fun observePeminjaman(): Flow<List<PeminjamanDetail>> = pinjamDao.observeDetail()

    fun observePeminjamanByUser(userId: Long): Flow<List<PeminjamanDetail>> =
        pinjamDao.observeDetailByUser(userId)

    fun observePeminjamanByBarang(barangId: Long): Flow<List<PeminjamanDetail>> =
        pinjamDao.observeDetailByBarang(barangId)

    suspend fun getSemuaPeminjaman(): List<PeminjamanDetail> = pinjamDao.getAllDetail()

    suspend fun getPeminjamanAktif(): List<PeminjamanDetail> = pinjamDao.getActiveDetail()

    suspend fun getDetailPeminjaman(id: Long): PeminjamanDetail? = pinjamDao.getDetailById(id)

    fun observeTotalPinjamUser(userId: Long): Flow<Int> = pinjamDao.observeTotalByUser(userId)

    /** Proses pinjam: validasi stok otomatis lalu kurangi stok tersedia */
    suspend fun pinjam(
        userId: Long, barangId: Long, jumlah: Int,
        tglPinjam: Long, tglKembali: Long, keperluan: String
    ): OpResult<Long> = db.withTransaction {
        val barang = barangDao.getById(barangId)
            ?: return@withTransaction OpResult.Gagal("Barang tidak ditemukan")
        userDao.getById(userId) ?: return@withTransaction OpResult.Gagal("Siswa tidak ditemukan")
        if (jumlah <= 0) return@withTransaction OpResult.Gagal("Jumlah harus lebih dari 0")
        if (barang.kondisi == Kondisi.RUSAK_BERAT) {
            return@withTransaction OpResult.Gagal("${barang.nama} rusak berat dan tidak bisa dipinjam")
        }
        if (barang.stokTersedia <= 0) {
            return@withTransaction OpResult.Gagal("Stok ${barang.nama} habis, tidak bisa dipinjam")
        }
        if (jumlah > barang.stokTersedia) {
            return@withTransaction OpResult.Gagal("Stok tersedia hanya ${barang.stokTersedia}")
        }
        if (DateUtils.startOfDay(tglKembali) < DateUtils.startOfDay(tglPinjam)) {
            return@withTransaction OpResult.Gagal("Tanggal kembali tidak boleh sebelum tanggal pinjam")
        }
        if (keperluan.isBlank()) return@withTransaction OpResult.Gagal("Keperluan wajib diisi")

        val id = pinjamDao.insert(
            PeminjamanEntity(
                userId = userId, barangId = barangId, jumlah = jumlah,
                tanggalPinjam = tglPinjam,
                tanggalJatuhTempo = DateUtils.endOfDay(tglKembali),
                keperluan = keperluan.trim(), status = StatusPinjam.DIPINJAM
            )
        )
        barangDao.adjustStok(barangId, -jumlah)
        OpResult.Sukses(id)
    }

    /** Proses kembali: tambah stok, hitung denda, simpan foto kondisi. Mengembalikan nilai denda */
    suspend fun kembalikan(
        peminjamanId: Long, fotoPath: String?, rusak: Boolean
    ): OpResult<Long> = db.withTransaction {
        val p = pinjamDao.getById(peminjamanId)
            ?: return@withTransaction OpResult.Gagal("Transaksi tidak ditemukan")
        if (!StatusPinjam.aktif(p.status)) {
            return@withTransaction OpResult.Gagal("Barang ini sudah dikembalikan")
        }
        val sekarang = System.currentTimeMillis()
        val denda = Denda.hitung(p.tanggalJatuhTempo, sekarang)
        pinjamDao.update(
            p.copy(
                status = if (rusak) StatusPinjam.RUSAK else StatusPinjam.DIKEMBALIKAN,
                tanggalKembali = sekarang,
                fotoKembali = fotoPath,
                denda = denda,
                kondisiKembali = if (rusak) "Rusak" else "Baik"
            )
        )
        barangDao.adjustStok(p.barangId, p.jumlah)
        if (rusak) {
            val barang = barangDao.getById(p.barangId)
            if (barang != null && barang.kondisi == Kondisi.BAIK) {
                barangDao.updateKondisi(barang.id, Kondisi.RUSAK_RINGAN)
            }
        }
        OpResult.Sukses(denda)
    }

    // ------------------------------------------------------------ Dashboard

    fun observeTotalStok(): Flow<Int> = barangDao.observeTotalStok()

    fun observeTotalTersedia(): Flow<Int> = barangDao.observeTotalTersedia()

    fun observeJumlahDipinjam(): Flow<Int> = pinjamDao.observeJumlahDipinjam()

    fun observeJumlahTerlambat(): Flow<Int> = pinjamDao.observeJumlahTerlambat()

    fun observeTanggalPinjamSejak(sejak: Long): Flow<List<Long>> =
        pinjamDao.observeTanggalPinjamSejak(sejak)
}
