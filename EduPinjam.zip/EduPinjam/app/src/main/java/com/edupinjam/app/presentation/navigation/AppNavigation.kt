package com.edupinjam.app.presentation.navigation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.Role
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.presentation.screen.BarangDetailScreen
import com.edupinjam.app.presentation.screen.BarangFormScreen
import com.edupinjam.app.presentation.screen.DashboardScreen
import com.edupinjam.app.presentation.screen.EditProfilScreen
import com.edupinjam.app.presentation.screen.GantiPasswordScreen
import com.edupinjam.app.presentation.screen.InventarisScreen
import com.edupinjam.app.presentation.screen.KelolaPetugasScreen
import com.edupinjam.app.presentation.screen.KembalikanScreen
import com.edupinjam.app.presentation.screen.LaporanScreen
import com.edupinjam.app.presentation.screen.LoginScreen
import com.edupinjam.app.presentation.screen.PengaturanScreen
import com.edupinjam.app.presentation.screen.PinjamScreen
import com.edupinjam.app.presentation.screen.ProfilScreen
import com.edupinjam.app.presentation.screen.RegisterScreen
import com.edupinjam.app.presentation.screen.RiwayatScreen
import com.edupinjam.app.presentation.screen.ScanScreen
import com.edupinjam.app.presentation.screen.SiswaHomeScreen
import com.edupinjam.app.presentation.viewmodel.AuthViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.White
import com.edupinjam.app.utils.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine

/** Daftar rute navigasi aplikasi */
object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"

    const val BERANDA = "beranda"
    const val INVENTARIS = "inventaris"
    const val PINJAM = "pinjam?barangId={barangId}"
    const val RIWAYAT = "riwayat"
    const val PROFIL = "profil"

    const val BARANG_DETAIL = "barang/{id}"
    const val BARANG_FORM = "barang_form?id={id}"
    const val KEMBALIKAN = "kembalikan/{id}"
    const val SCAN = "scan"
    const val LAPORAN = "laporan"
    const val KELOLA_PETUGAS = "kelola_petugas"
    const val GANTI_PASSWORD = "ganti_password"
    const val PENGATURAN = "pengaturan"
    const val EDIT_PROFIL = "edit_profil"

    fun barangDetail(id: Long) = "barang/$id"
    fun barangForm(id: Long? = null) = if (id == null) "barang_form" else "barang_form?id=$id"
    fun kembalikan(id: Long) = "kembalikan/$id"
    fun pinjam(barangId: Long? = null) = if (barangId == null) "pinjam" else "pinjam?barangId=$barangId"
}

/** Navigasi sebelum login: Login dan Register */
@Composable
fun AuthNav(vm: AuthViewModel) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) { LoginScreen(vm, onRegister = { nav.navigate(Routes.REGISTER) }) }
        composable(Routes.REGISTER) { RegisterScreen(vm, onBack = { nav.popBackStack() }) }
    }
}

/** Item bottom navigation */
private data class TabItem(val label: String, val ikon: ImageVector, val rute: String, val tujuan: String)

private val daftarTab = listOf(
    TabItem("Beranda", Icons.Filled.Home, Routes.BERANDA, Routes.BERANDA),
    TabItem("Inventaris", Icons.Filled.Inventory2, Routes.INVENTARIS, Routes.INVENTARIS),
    TabItem("Pinjam", Icons.Filled.SwapHoriz, Routes.PINJAM, Routes.pinjam()),
    TabItem("Riwayat", Icons.Filled.History, Routes.RIWAYAT, Routes.RIWAYAT),
    TabItem("Profil", Icons.Filled.Person, Routes.PROFIL, Routes.PROFIL)
)

/** Pindah antar tab tanpa menumpuk back stack */
private fun NavHostController.pindahTab(tujuan: String) {
    navigate(tujuan) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Menjadwalkan notifikasi pengingat H-1 selama pengguna login */
@Composable
private fun PengingatEffect() {
    val app = rememberApp()
    val context = LocalContext.current

    val izin = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) izin.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // Status Terlambat diperbarui tiap menit selama aplikasi terbuka
    LaunchedEffect(Unit) {
        while (true) {
            app.repository.refreshTerlambat()
            delay(60_000)
        }
    }

    // Jadwal ulang pengingat setiap data peminjaman atau pengaturan berubah
    LaunchedEffect(Unit) {
        combine(app.repository.observePeminjaman(), app.session.pengingatAktif) { semua, aktif ->
            semua.filter { StatusPinjam.aktif(it.peminjaman.status) } to aktif
        }.collect { (aktifList, nyala) ->
            if (nyala) NotificationHelper.jadwalkanPengingat(context, aktifList)
            else NotificationHelper.batalkanSemua(context, aktifList)
        }
    }
}

/** Navigasi utama setelah login, lengkap dengan bottom navigation */
@Composable
fun MainNav(user: UserEntity) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val rute = backStack?.destination?.route
    val staf = Role.isStaff(user.role)
    val tampilBar = daftarTab.any { it.rute == rute }

    PengingatEffect()

    Scaffold(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
        bottomBar = {
            if (tampilBar) {
                NavigationBar(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface) {
                    daftarTab.forEach { tab ->
                        NavigationBarItem(
                            selected = rute == tab.rute,
                            onClick = { nav.pindahTab(tab.tujuan) },
                            icon = { Icon(tab.ikon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = White,
                                selectedTextColor = SkyBlue,
                                indicatorColor = SkyBlue
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.BERANDA,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.BERANDA) {
                if (staf) {
                    DashboardScreen(
                        user = user,
                        onTambahBarang = { nav.navigate(Routes.barangForm()) },
                        onPinjam = { nav.pindahTab(Routes.pinjam()) },
                        onScan = { nav.navigate(Routes.SCAN) },
                        onLihatSemua = { nav.pindahTab(Routes.RIWAYAT) }
                    )
                } else {
                    SiswaHomeScreen(
                        user = user,
                        onPinjam = { nav.pindahTab(Routes.pinjam()) },
                        onScan = { nav.navigate(Routes.SCAN) }
                    )
                }
            }

            composable(Routes.INVENTARIS) {
                InventarisScreen(
                    adalahStaf = staf,
                    onDetail = { nav.navigate(Routes.barangDetail(it)) },
                    onTambah = { nav.navigate(Routes.barangForm()) }
                )
            }

            composable(
                Routes.PINJAM,
                arguments = listOf(navArgument("barangId") { type = NavType.LongType; defaultValue = -1L })
            ) { entry ->
                PinjamScreen(
                    user = user,
                    barangAwal = entry.arguments?.getLong("barangId")?.takeIf { it > 0 },
                    onKembalikan = { nav.navigate(Routes.kembalikan(it)) }
                )
            }

            composable(Routes.RIWAYAT) {
                RiwayatScreen(
                    user = user,
                    onKembalikan = { nav.navigate(Routes.kembalikan(it)) },
                    onLaporan = { nav.navigate(Routes.LAPORAN) }
                )
            }

            composable(Routes.PROFIL) {
                ProfilScreen(
                    user = user,
                    onEdit = { nav.navigate(Routes.EDIT_PROFIL) },
                    onGantiPassword = { nav.navigate(Routes.GANTI_PASSWORD) },
                    onKelolaPetugas = { nav.navigate(Routes.KELOLA_PETUGAS) },
                    onPengaturan = { nav.navigate(Routes.PENGATURAN) },
                    onLaporan = { nav.navigate(Routes.LAPORAN) }
                )
            }

            composable(
                Routes.BARANG_DETAIL,
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: -1L
                BarangDetailScreen(
                    barangId = id,
                    adalahStaf = staf,
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Routes.barangForm(it)) },
                    onPinjam = { nav.navigate(Routes.pinjam(it)) }
                )
            }

            composable(
                Routes.BARANG_FORM,
                arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: -1L
                BarangFormScreen(
                    barangId = id.takeIf { it > 0 },
                    onSelesai = { nav.popBackStack() },
                    onBack = { nav.popBackStack() }
                )
            }

            composable(
                Routes.KEMBALIKAN,
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                KembalikanScreen(
                    peminjamanId = entry.arguments?.getLong("id") ?: -1L,
                    onSelesai = { nav.popBackStack() },
                    onBack = { nav.popBackStack() }
                )
            }

            composable(Routes.SCAN) {
                ScanScreen(
                    adalahStaf = staf,
                    onBack = { nav.popBackStack() },
                    onPinjam = { id ->
                        nav.navigate(Routes.pinjam(id)) { popUpTo(Routes.SCAN) { inclusive = true } }
                    },
                    onKembalikan = { nav.navigate(Routes.kembalikan(it)) },
                    onDetail = { nav.navigate(Routes.barangDetail(it)) }
                )
            }

            composable(Routes.LAPORAN) { LaporanScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.KELOLA_PETUGAS) { KelolaPetugasScreen(user, onBack = { nav.popBackStack() }) }
            composable(Routes.GANTI_PASSWORD) { GantiPasswordScreen(user, onBack = { nav.popBackStack() }) }
            composable(Routes.PENGATURAN) { PengaturanScreen(user, onBack = { nav.popBackStack() }) }
            composable(Routes.EDIT_PROFIL) { EditProfilScreen(user, onBack = { nav.popBackStack() }) }
        }
    }
}
