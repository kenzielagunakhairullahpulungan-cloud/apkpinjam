package com.edupinjam.app.presentation.viewmodel

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.edupinjam.app.EduPinjamApp

/** Factory generik: membuat ViewModel dengan dependency manual (tanpa Hilt) */
@Suppress("UNCHECKED_CAST")
fun <T : ViewModel> vmFactory(buat: () -> T): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        override fun <V : ViewModel> create(modelClass: Class<V>): V = buat() as V
    }

/** Mengambil Application agar screen bisa mengakses repository dan session */
@Composable
fun rememberApp(): EduPinjamApp = LocalContext.current.applicationContext as EduPinjamApp
