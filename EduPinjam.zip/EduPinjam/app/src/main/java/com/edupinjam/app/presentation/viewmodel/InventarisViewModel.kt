package com.edupinjam.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edupinjam.app.data.local.BarangEntity
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.domain.OpResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Pilihan pengurutan daftar barang */
enum class UrutBarang(val label: String) {
    NAMA_AZ("Nama A-Z"),
    NAMA_ZA("Nama Z-A"),
    STOK_BANYAK("Stok Terbanyak"),
    STOK_SEDIKIT("Stok Tersedikit")
}

/** ViewModel daftar inventaris: search, filter kategori, sort, dan CRUD */
class InventarisViewModel(private val repo: AppRepository) : ViewModel() {

    val query = MutableStateFlow("")
    val kategori = MutableStateFlow<String?>(null)
    val urut = MutableStateFlow(UrutBarang.NAMA_AZ)

    val barang: StateFlow<List<BarangEntity>> = combine(
        repo.observeBarang(), query, kategori, urut
    ) { semua, q, kat, urutan ->
        val terfilter = semua.filter { b ->
            (kat == null || b.kategori == kat) &&
                (q.isBlank() || b.nama.contains(q, ignoreCase = true) ||
                    b.kode.contains(q, ignoreCase = true) || b.lokasiRak.contains(q, ignoreCase = true))
        }
        when (urutan) {
            UrutBarang.NAMA_AZ -> terfilter.sortedBy { it.nama.lowercase() }
            UrutBarang.NAMA_ZA -> terfilter.sortedByDescending { it.nama.lowercase() }
            UrutBarang.STOK_BANYAK -> terfilter.sortedByDescending { it.stokTersedia }
            UrutBarang.STOK_SEDIKIT -> terfilter.sortedBy { it.stokTersedia }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Simpan (tambah/ubah) barang; hasil dikirim lewat callback di main thread */
    fun simpan(b: BarangEntity, selesai: (OpResult<Long>) -> Unit) {
        viewModelScope.launch { selesai(repo.simpanBarang(b)) }
    }

    fun hapus(id: Long, selesai: (OpResult<Unit>) -> Unit) {
        viewModelScope.launch { selesai(repo.hapusBarang(id)) }
    }

    suspend fun ambil(id: Long): BarangEntity? = repo.getBarang(id)

    suspend fun kodeBerikutnya(): String = repo.kodeBerikutnya()
}

/** ViewModel detail barang: data barang dan riwayat peminjamannya */
class BarangDetailViewModel(repo: AppRepository, barangId: Long) : ViewModel() {
    val barang: StateFlow<BarangEntity?> = repo.observeBarang(barangId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val riwayat: StateFlow<List<PeminjamanDetail>> = repo.observePeminjamanByBarang(barangId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
