package com.edupinjam.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.data.preferences.SessionManager
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.domain.OpResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Status autentikasi aplikasi */
sealed class AuthState {
    object Memuat : AuthState()
    object Keluar : AuthState()
    data class Masuk(val user: UserEntity) : AuthState()
}

/** ViewModel login, register, logout, dan pemantau sesi dari DataStore */
@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModel(
    private val repo: AppRepository,
    private val session: SessionManager
) : ViewModel() {

    private val siap = MutableStateFlow(false)

    private val statusSesi: Flow<AuthState> = session.sesi.flatMapLatest { s ->
        if (s == null) {
            flowOf<AuthState>(AuthState.Keluar)
        } else {
            repo.observeUser(s.userId).map<UserEntity?, AuthState> { u ->
                if (u == null) AuthState.Keluar else AuthState.Masuk(u)
            }
        }
    }

    /** Selama splash (siap = false) status tetap Memuat */
    val state: StateFlow<AuthState> = combine(siap, statusSesi) { ok, st ->
        if (ok) st else AuthState.Memuat
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AuthState.Memuat)

    val sedangProses = MutableStateFlow(false)
    val pesan = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repo.seedIfEmpty()
            repo.refreshTerlambat()
            delay(1500) // durasi splash screen
            siap.value = true
        }
    }

    fun bersihkanPesan() {
        pesan.value = null
    }

    /** Login dengan memeriksa kecocokan peran yang dipilih */
    fun login(peran: String, username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            pesan.value = "Username dan password wajib diisi"
            return
        }
        viewModelScope.launch {
            sedangProses.value = true
            val user = repo.login(username, password)
            when {
                user == null -> pesan.value = "Username atau password salah"
                user.role != peran -> pesan.value = "Akun ini bukan akun ${com.edupinjam.app.domain.Role.label(peran)}"
                else -> session.simpanSesi(user.id, user.role)
            }
            sedangProses.value = false
        }
    }

    /** Daftar siswa baru lalu langsung login */
    fun register(nama: String, nis: String, kelas: String, noHp: String, password: String) {
        viewModelScope.launch {
            sedangProses.value = true
            when (val hasil = repo.registerSiswa(nama, nis, kelas, noHp, password)) {
                is OpResult.Gagal -> pesan.value = hasil.pesan
                is OpResult.Sukses -> session.simpanSesi(hasil.data, com.edupinjam.app.domain.Role.SISWA)
            }
            sedangProses.value = false
        }
    }
}
