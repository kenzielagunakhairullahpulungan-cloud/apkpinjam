package com.edupinjam.app.utils

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.edupinjam.app.MainActivity
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.domain.DAY_MS

/** Pembuat channel dan penjadwal notifikasi pengingat H-1 jatuh tempo */
object NotificationHelper {
    const val CHANNEL_ID = "edupinjam_pengingat"
    private const val EXTRA_ID = "peminjaman_id"
    private const val EXTRA_TEKS = "teks"

    fun buatChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Pengingat Pengembalian", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Pengingat H-1 sebelum jatuh tempo pengembalian barang" }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun intentUntuk(context: Context, id: Long, teks: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TEKS, teks)
        }
        return PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Jadwalkan pengingat H-1 pukul 08:00 untuk semua peminjaman aktif yang belum lewat */
    fun jadwalkanPengingat(context: Context, aktif: List<PeminjamanDetail>) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val sekarang = System.currentTimeMillis()
        aktif.forEach { d ->
            val p = d.peminjaman
            // H-1 pukul 08:00 sebelum hari jatuh tempo
            val waktu = DateUtils.startOfDay(p.tanggalJatuhTempo) - DAY_MS + 8 * 3_600_000L
            val teks = "${d.namaSiswa}: ${d.namaBarang} harus dikembalikan besok (" +
                DateUtils.formatTanggal(p.tanggalJatuhTempo) + ")"
            val pi = intentUntuk(context, p.id, teks)
            if (waktu > sekarang) {
                // Alarm tidak presisi agar tidak butuh izin khusus exact alarm
                am.set(AlarmManager.RTC_WAKEUP, waktu, pi)
            }
        }
    }

    fun batalkanSemua(context: Context, aktif: List<PeminjamanDetail>) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        aktif.forEach { am.cancel(intentUntuk(context, it.peminjaman.id, "")) }
    }

    /** Tampilkan notifikasi sekarang (dipakai ReminderReceiver) */
    fun tampilkan(context: Context, id: Long, teks: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val buka = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pengingat EDU-PINJAM")
            .setContentText(teks)
            .setStyle(NotificationCompat.BigTextStyle().bigText(teks))
            .setContentIntent(buka)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(id.toInt(), notif)
    }

    fun ambilId(intent: Intent): Long = intent.getLongExtra(EXTRA_ID, 0L)
    fun ambilTeks(intent: Intent): String = intent.getStringExtra(EXTRA_TEKS).orEmpty()
}

/** Menerima alarm dan menampilkan notifikasi pengingat */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationHelper.tampilkan(
            context, NotificationHelper.ambilId(intent), NotificationHelper.ambilTeks(intent)
        )
    }
}
