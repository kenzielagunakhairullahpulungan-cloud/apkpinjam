@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.Role
import com.edupinjam.app.presentation.viewmodel.FilterRiwayat
import com.edupinjam.app.presentation.viewmodel.LaporanViewModel
import com.edupinjam.app.presentation.viewmodel.RiwayatViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.EmptyState
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.components.SecondaryButton
import com.edupinjam.app.ui.components.SectionTitle
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.White
import com.edupinjam.app.utils.DateUtils
import com.edupinjam.app.utils.ExportUtils
import com.edupinjam.app.utils.RupiahFormat

/** Tab Riwayat: filter Semua / Dipinjam / Dikembalikan / Terlambat / Rusak */
@Composable
fun RiwayatScreen(user: UserEntity, onKembalikan: (Long) -> Unit, onLaporan: () -> Unit) {
    val app = rememberApp()
    val staf = Role.isStaff(user.role)
    val vm: RiwayatViewModel = viewModel(
        key = "riwayat_${user.id}",
        factory = vmFactory { RiwayatViewModel(app.repository, if (staf) null else user.id) }
    )
    val daftar by vm.daftar.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Riwayat", actions = {
            if (staf) {
                IconButton(onClick = onLaporan) { Icon(Icons.Filled.Assessment, contentDescription = "Laporan") }
            }
        })
        OutlinedTextField(
            value = query, onValueChange = { vm.query.value = it },
            placeholder = { Text(if (staf) "Cari barang atau siswa..." else "Cari barang...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = SkyBlue) },
            singleLine = true, shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(FilterRiwayat.values().toList()) { f ->
                FilterChip(
                    selected = filter == f, onClick = { vm.filter.value = f },
                    label = { Text(f.label) }, shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = SkyBlue, selectedLabelColor = White)
                )
            }
        }
        if (daftar.isEmpty()) {
            EmptyState("Tidak ada data peminjaman")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(daftar, key = { it.peminjaman.id }) { d ->
                    val aktif = d.peminjaman.tanggalKembali == null
                    PeminjamanItem(
                        d, tampilkanSiswa = staf,
                        aksi = if (staf && aktif) {
                            { PrimaryButton("Kembalikan", onClick = { onKembalikan(d.peminjaman.id) }) }
                        } else null
                    )
                }
            }
        }
    }
}

/** Laporan bulanan: barang terpopuler, siswa teraktif, export PDF / Excel */
@Composable
fun LaporanScreen(onBack: () -> Unit) {
    val app = rememberApp()
    val context = LocalContext.current
    val vm: LaporanViewModel = viewModel(factory = vmFactory { LaporanViewModel(app.repository) })
    val l by vm.laporan.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Laporan Bulanan", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Pemilih bulan
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = { vm.geser(-1) }) { Icon(Icons.Filled.ChevronLeft, contentDescription = "Bulan sebelumnya", tint = SkyBlue) }
                Text(l.labelBulan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = { vm.geser(1) }) { Icon(Icons.Filled.ChevronRight, contentDescription = "Bulan berikutnya", tint = SkyBlue) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                EduCard(Modifier.weight(1f)) {
                    Text("${l.totalTransaksi}", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = SkyBlue)
                    Text("Transaksi", fontSize = 12.sp)
                }
                EduCard(Modifier.weight(1f)) {
                    Text("${l.totalUnit}", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = SkyBlue)
                    Text("Unit dipinjam", fontSize = 12.sp)
                }
                EduCard(Modifier.weight(1f)) {
                    Text(RupiahFormat.format(l.totalDenda), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = RedBad)
                    Text("Total denda", fontSize = 12.sp)
                }
            }

            SectionTitle("Barang Paling Sering Dipinjam")
            EduCard(Modifier.fillMaxWidth()) {
                if (l.barangPopuler.isEmpty()) Text("Belum ada data bulan ini", fontSize = 13.sp)
                l.barangPopuler.forEachIndexed { i, b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${i + 1}. ${b.nama}", fontSize = 14.sp)
                        Text("${b.jumlah}x", fontWeight = FontWeight.Bold, color = SkyBlue)
                    }
                }
            }

            SectionTitle("Siswa Paling Aktif Meminjam")
            EduCard(Modifier.fillMaxWidth()) {
                if (l.siswaAktif.isEmpty()) Text("Belum ada data bulan ini", fontSize = 13.sp)
                l.siswaAktif.forEachIndexed { i, s ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${i + 1}. ${s.nama} (${s.nis})", fontSize = 14.sp)
                        Text("${s.jumlah}x", fontWeight = FontWeight.Bold, color = SkyBlue)
                    }
                }
            }

            SectionTitle("Export Laporan")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(
                    "PDF", icon = Icons.Filled.PictureAsPdf, modifier = Modifier.weight(1f),
                    onClick = {
                        try {
                            ExportUtils.bagikan(context, ExportUtils.exportPdf(context, l), "application/pdf")
                        } catch (e: Exception) {
                            Toast.makeText(context, "Gagal membuat PDF", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                SecondaryButton(
                    "Excel", icon = Icons.Filled.TableChart, modifier = Modifier.weight(1f),
                    onClick = {
                        try {
                            ExportUtils.bagikan(context, ExportUtils.exportExcel(context, l), "application/vnd.ms-excel")
                        } catch (e: Exception) {
                            Toast.makeText(context, "Gagal membuat file Excel", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            SectionTitle("Transaksi Bulan Ini")
            if (l.transaksi.isEmpty()) EmptyState("Tidak ada transaksi pada ${l.labelBulan}")
            l.transaksi.reversed().forEach { PeminjamanItem(it) }
            Spacer(Modifier.height(8.dp))
        }
    }
}
