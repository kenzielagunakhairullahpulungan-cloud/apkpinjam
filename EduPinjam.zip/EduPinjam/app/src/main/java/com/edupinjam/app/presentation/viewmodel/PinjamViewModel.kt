package com.edupinjam.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edupinjam.app.data.local.BarangEntity
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.domain.DAY_MS
import com.edupinjam.app.domain.OpResult
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.utils.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel form peminjaman.
 * [siswaTetapId] diisi bila yang login adalah siswa (form dikunci untuk dirinya sendiri).
 */
class PinjamViewModel(
    private val repo: AppRepository,
    private val siswaTetapId: Long?
) : ViewModel() {

    val daftarSiswa: StateFlow<List<UserEntity>> = repo.observeSiswa()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val daftarBarang: StateFlow<List<BarangEntity>> = repo.observeBarang()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val siswaId = MutableStateFlow(siswaTetapId)
    val barangId = MutableStateFlow<Long?>(null)
    val jumlah = MutableStateFlow("1")
    val tglPinjam = MutableStateFlow(DateUtils.startOfDay(System.currentTimeMillis()))
    val tglKembali = MutableStateFlow(DateUtils.startOfDay(System.currentTimeMillis()) + 7 * DAY_MS)
    val keperluan = MutableStateFlow("")

    /** Pesan hasil: pair (sukses?, teks) */
    val hasil = MutableStateFlow<Pair<Boolean, String>?>(null)
    val sedangProses = MutableStateFlow(false)

    /** Barang yang dipilih (untuk menampilkan stok tersedia) */
    val barangTerpilih: StateFlow<BarangEntity?> = combine(daftarBarang, barangId) { list, id ->
        list.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun bersihkanHasil() {
        hasil.value = null
    }

    /** Ubah jumlah dengan menyaring hanya angka */
    fun ubahJumlah(teks: String) {
        jumlah.value = teks.filter { it.isDigit() }.take(4)
    }

    fun ubahTglPinjam(ts: Long) {
        tglPinjam.value = ts
        if (tglKembali.value < ts) tglKembali.value = ts + DAY_MS
    }

    fun kirim() {
        val s = siswaId.value
        val b = barangId.value
        if (s == null) { hasil.value = false to "Pilih siswa terlebih dahulu"; return }
        if (b == null) { hasil.value = false to "Pilih barang terlebih dahulu"; return }
        val j = jumlah.value.toIntOrNull()
        if (j == null || j <= 0) { hasil.value = false to "Jumlah harus lebih dari 0"; return }
        viewModelScope.launch {
            sedangProses.value = true
            when (val r = repo.pinjam(s, b, j, tglPinjam.value, tglKembali.value, keperluan.value)) {
                is OpResult.Gagal -> hasil.value = false to r.pesan
                is OpResult.Sukses -> {
                    hasil.value = true to "Peminjaman berhasil dicatat. Stok berkurang otomatis."
                    // Reset form tetapi pertahankan siswa tetap
                    barangId.value = null
                    jumlah.value = "1"
                    keperluan.value = ""
                }
            }
            sedangProses.value = false
        }
    }
}

/** Opsi filter riwayat */
enum class FilterRiwayat(val label: String) {
    SEMUA("Semua"),
    DIPINJAM("Dipinjam"),
    DIKEMBALIKAN("Dikembalikan"),
    TERLAMBAT("Terlambat"),
    RUSAK("Rusak")
}

/** ViewModel riwayat; [userId] diisi untuk menampilkan riwayat satu siswa saja */
class RiwayatViewModel(repo: AppRepository, userId: Long?) : ViewModel() {

    val filter = MutableStateFlow(FilterRiwayat.SEMUA)
    val query = MutableStateFlow("")

    private val sumber = if (userId != null) repo.observePeminjamanByUser(userId) else repo.observePeminjaman()

    val daftar: StateFlow<List<PeminjamanDetail>> = combine(sumber, filter, query) { semua, f, q ->
        semua.filter { d ->
            val st = d.peminjaman.status
            val cocokStatus = when (f) {
                FilterRiwayat.SEMUA -> true
                FilterRiwayat.DIPINJAM -> st == StatusPinjam.DIPINJAM
                FilterRiwayat.DIKEMBALIKAN -> st == StatusPinjam.DIKEMBALIKAN
                FilterRiwayat.TERLAMBAT -> st == StatusPinjam.TERLAMBAT
                FilterRiwayat.RUSAK -> st == StatusPinjam.RUSAK
            }
            cocokStatus && (q.isBlank() || d.namaBarang.contains(q, true) || d.namaSiswa.contains(q, true))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Daftar yang masih aktif (belum dikembalikan) untuk tab "Sedang Dipinjam" */
    val aktif: StateFlow<List<PeminjamanDetail>> = sumber
        .map { list -> list.filter { StatusPinjam.aktif(it.peminjaman.status) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

/** ViewModel layar pengembalian barang */
class KembalikanViewModel(private val repo: AppRepository, private val peminjamanId: Long) : ViewModel() {

    val detail = MutableStateFlow<PeminjamanDetail?>(null)
    val fotoPath = MutableStateFlow<String?>(null)
    val rusak = MutableStateFlow(false)
    val sedangProses = MutableStateFlow(false)
    val pesanError = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch { detail.value = repo.getDetailPeminjaman(peminjamanId) }
    }

    /** Simpan pengembalian; [selesai] menerima nilai denda */
    fun kembalikan(selesai: (Long) -> Unit) {
        viewModelScope.launch {
            sedangProses.value = true
            when (val r = repo.kembalikan(peminjamanId, fotoPath.value, rusak.value)) {
                is OpResult.Gagal -> pesanError.value = r.pesan
                is OpResult.Sukses -> selesai(r.data)
            }
            sedangProses.value = false
        }
    }
}

/** Hasil pencarian barang dari QR */
data class HasilScan(val barang: BarangEntity?, val kode: String, val aktif: List<PeminjamanDetail>)

/** ViewModel scan QR: cari barang dari kode dan pinjaman aktifnya */
class ScanViewModel(private val repo: AppRepository) : ViewModel() {

    val hasil = MutableStateFlow<HasilScan?>(null)

    fun proses(kode: String) {
        viewModelScope.launch {
            val barang = repo.getBarangByKode(kode)
            val aktif = if (barang != null) {
                repo.getPeminjamanAktif().filter { it.peminjaman.barangId == barang.id }
            } else emptyList()
            hasil.value = HasilScan(barang, kode, aktif)
        }
    }

    fun ulang() {
        hasil.value = null
    }
}
