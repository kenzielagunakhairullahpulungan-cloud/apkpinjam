package com.edupinjam.app.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.edupinjam.app.data.local.AppDatabase
import java.io.File

/** Backup dan restore file database Room */
object BackupUtils {

    /** Buat salinan database ke cache lalu kembalikan file-nya */
    fun buatBackup(context: Context, db: AppDatabase): File {
        // Pastikan isi WAL ikut tertulis ke file utama sebelum disalin
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val sumber = context.getDatabasePath(AppDatabase.NAMA_DB)
        val folder = File(context.cacheDir, "backup").apply { mkdirs() }
        val tujuan = File(folder, "EDU-PINJAM_backup_${System.currentTimeMillis()}.db")
        sumber.copyTo(tujuan, overwrite = true)
        return tujuan
    }

    fun bagikan(context: Context, file: File) {
        val uri = ImageUtils.uriUntukFile(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Simpan backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Header file SQLite selalu diawali teks "SQLite format 3" */
    private fun validSqlite(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buf = ByteArray(15)
            input.read(buf) == 15 && String(buf) == "SQLite format 3"
        } ?: false
    } catch (e: Exception) {
        false
    }

    /** Pulihkan database dari file backup. Mengembalikan true bila berhasil (aplikasi harus dibuka ulang) */
    fun restore(context: Context, uri: Uri): Boolean {
        if (!validSqlite(context, uri)) return false
        return try {
            AppDatabase.tutup()
            val target = context.getDatabasePath(AppDatabase.NAMA_DB)
            // Hapus file pendamping WAL/SHM agar tidak bentrok dengan database hasil restore
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }
}
