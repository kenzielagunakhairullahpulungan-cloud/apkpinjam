@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalGetImage::class)

package com.edupinjam.app.presentation.screen

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.presentation.viewmodel.HasilScan
import com.edupinjam.app.presentation.viewmodel.ScanViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EduTextField
import com.edupinjam.app.ui.components.EduTopBar
import com.edupinjam.app.ui.components.PrimaryButton
import com.edupinjam.app.ui.components.SecondaryButton
import com.edupinjam.app.ui.components.SectionTitle
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Pratinjau kamera + ML Kit Barcode Scanning khusus QR Code */
@Composable
private fun CameraPreview(onKode: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }
    val scanner = remember {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        )
    }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val kodeTerbaru by rememberUpdatedState(onKode)
    // Penanda agar satu QR hanya diproses sekali
    val sudahTerbaca = remember { AtomicBoolean(false) }

    DisposableEffect(lifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            val p = future.get()
            provider = p
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analisa = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analisa.setAnalyzer(executor) { proxy ->
                val media = proxy.image
                if (media == null || sudahTerbaca.get()) {
                    proxy.close()
                } else {
                    val gambar = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(gambar)
                        .addOnSuccessListener { daftar ->
                            val nilai = daftar.firstOrNull()?.rawValue
                            if (!nilai.isNullOrBlank() && sudahTerbaca.compareAndSet(false, true)) {
                                previewView.post { kodeTerbaru(nilai) }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
            }
            try {
                p.unbindAll()
                p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analisa)
            } catch (_: Exception) {
                // Kamera tidak tersedia; pengguna masih bisa memakai input kode manual
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            provider?.unbindAll()
            executor.shutdown()
            scanner.close()
        }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}

/** Layar scan QR: pinjam atau kembalikan lebih cepat */
@Composable
fun ScanScreen(
    adalahStaf: Boolean,
    onBack: () -> Unit,
    onPinjam: (Long) -> Unit,
    onKembalikan: (Long) -> Unit,
    onDetail: (Long) -> Unit
) {
    val app = rememberApp()
    val context = LocalContext.current
    val vm: ScanViewModel = viewModel(factory = vmFactory { ScanViewModel(app.repository) })
    val hasil by vm.hasil.collectAsStateWithLifecycle()
    var izin by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val peminta = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { izin = it }
    var kodeManual by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { if (!izin) peminta.launch(Manifest.permission.CAMERA) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        EduTopBar("Scan QR Code", onBack = onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val h = hasil
            if (h == null) {
                if (izin) {
                    Box(Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(16.dp)).background(SkyBlue)) {
                        CameraPreview(onKode = { vm.proses(it) }, modifier = Modifier.fillMaxSize())
                    }
                    Text(
                        "Arahkan kamera ke QR Code pada barang", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    EduCard(Modifier.fillMaxWidth()) {
                        Text("Izin kamera belum diberikan", fontWeight = FontWeight.Bold)
                        Text("Berikan izin kamera untuk memindai QR, atau masukkan kode barang secara manual di bawah.", fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        PrimaryButton("Berikan Izin", onClick = { peminta.launch(Manifest.permission.CAMERA) })
                    }
                }
                SectionTitle("Atau masukkan kode manual")
                EduTextField(kodeManual, { kodeManual = it.uppercase() }, "Kode Barang (contoh: EDU-001)")
                SecondaryButton(
                    "Cari Barang", icon = Icons.Filled.QrCodeScanner,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = kodeManual.isNotBlank(),
                    onClick = { vm.proses(kodeManual.trim()) }
                )
            } else {
                HasilScanView(h, adalahStaf, onPinjam, onKembalikan, onDetail, onUlang = { vm.ulang(); kodeManual = "" })
            }
        }
    }
}

@Composable
private fun HasilScanView(
    h: HasilScan,
    adalahStaf: Boolean,
    onPinjam: (Long) -> Unit,
    onKembalikan: (Long) -> Unit,
    onDetail: (Long) -> Unit,
    onUlang: () -> Unit
) {
    val barang = h.barang
    if (barang == null) {
        EduCard(Modifier.fillMaxWidth()) {
            Text("Barang tidak ditemukan", fontWeight = FontWeight.Bold, color = RedBad)
            Text("Kode terbaca: ${h.kode}", fontSize = 13.sp)
        }
    } else {
        BarangCard(barang, onClick = { onDetail(barang.id) })
        PrimaryButton(
            text = if (barang.stokTersedia > 0) "Pinjam Barang Ini" else "Stok Habis",
            icon = Icons.Filled.SwapHoriz,
            enabled = barang.stokTersedia > 0,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onPinjam(barang.id) }
        )
        if (adalahStaf) {
            SectionTitle("Sedang Dipinjam (${h.aktif.size})")
            if (h.aktif.isEmpty()) {
                Text("Tidak ada peminjaman aktif untuk barang ini", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            h.aktif.forEach { d ->
                PeminjamanItem(d, aksi = {
                    PrimaryButton("Kembalikan", onClick = { onKembalikan(d.peminjaman.id) })
                })
            }
        }
    }
    SecondaryButton("Scan Lagi", onClick = onUlang, modifier = Modifier.fillMaxWidth())
}
