@file:OptIn(ExperimentalMaterial3Api::class)

package com.edupinjam.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.domain.StokLevel
import com.edupinjam.app.domain.stokLevel
import com.edupinjam.app.ui.theme.GreenOk
import com.edupinjam.app.ui.theme.GreenOkBg
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.RedBadBg
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.SkyDeep
import com.edupinjam.app.ui.theme.White
import com.edupinjam.app.ui.theme.YellowWarn
import com.edupinjam.app.ui.theme.YellowWarnBg
import com.edupinjam.app.utils.DateUtils
import com.edupinjam.app.utils.QrUtils
import java.io.File

/** Header sky blue dengan tombol kembali opsional */
@Composable
fun EduTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 1) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SkyBlue,
            titleContentColor = White,
            navigationIconContentColor = White,
            actionIconContentColor = White
        )
    )
}

/** Tombol utama: sky blue, teks putih, sudut 12dp */
@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = SkyBlue, contentColor = White)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

/** Tombol sekunder: garis tepi sky blue */
@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlue)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

/** Kartu sky blue muda, sudut 16dp, bayangan lembut */
@Composable
fun EduCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val base = modifier.shadow(3.dp, shape, ambientColor = SkyBlue.copy(alpha = 0.25f), spotColor = SkyBlue.copy(alpha = 0.25f))
    val colors = CardDefaults.cardColors(containerColor = container)
    if (onClick != null) {
        Card(onClick = onClick, modifier = base, shape = shape, colors = colors) {
            Column(Modifier.padding(14.dp), content = content)
        }
    } else {
        Card(modifier = base, shape = shape, colors = colors) {
            Column(Modifier.padding(14.dp), content = content)
        }
    }
}

/** Lencana kecil berwarna */
@Composable
fun Badge(text: String, fg: Color, bg: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Badge status peminjaman */
@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
    val (fg, bg) = when (status) {
        StatusPinjam.DIKEMBALIKAN -> GreenOk to GreenOkBg
        StatusPinjam.TERLAMBAT -> RedBad to RedBadBg
        StatusPinjam.RUSAK -> YellowWarn to YellowWarnBg
        else -> SkyDeep to Color(0xFFBAE6FD)
    }
    Badge(status, fg, bg, modifier)
}

/** Badge stok: hijau tersedia, kuning sisa sedikit, merah habis */
@Composable
fun StokBadge(tersedia: Int, modifier: Modifier = Modifier) {
    val level = stokLevel(tersedia)
    val (fg, bg) = when (level) {
        StokLevel.TERSEDIA -> GreenOk to GreenOkBg
        StokLevel.SISA_SEDIKIT -> YellowWarn to YellowWarnBg
        StokLevel.HABIS -> RedBad to RedBadBg
    }
    Badge(level.label, fg, bg, modifier)
}

/** Warna indikator stok untuk titik/angka */
fun stokColor(tersedia: Int): Color = when (stokLevel(tersedia)) {
    StokLevel.TERSEDIA -> GreenOk
    StokLevel.SISA_SEDIKIT -> YellowWarn
    StokLevel.HABIS -> RedBad
}

/** Foto barang; bila belum ada foto tampil ikon kotak inventaris */
@Composable
fun BarangImage(path: String?, modifier: Modifier = Modifier, ukuran: Dp = 64.dp) {
    val bentuk = RoundedCornerShape(12.dp)
    val file = remember(path) { path?.let { File(it) }?.takeIf { it.exists() } }
    Box(
        modifier = modifier
            .size(ukuran)
            .clip(bentuk)
            .background(Color(0xFFBAE6FD)),
        contentAlignment = Alignment.Center
    ) {
        if (file != null) {
            AsyncImage(
                model = file, contentDescription = "Foto",
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
        } else {
            Icon(Icons.Filled.Inventory2, contentDescription = null, tint = SkyBlue, modifier = Modifier.size(ukuran / 2))
        }
    }
}

/** Foto bulat untuk profil */
@Composable
fun AvatarImage(path: String?, inisial: String, ukuran: Dp = 80.dp) {
    val file = remember(path) { path?.let { File(it) }?.takeIf { it.exists() } }
    Box(
        modifier = Modifier.size(ukuran).clip(CircleShape).background(Color(0xFFBAE6FD)),
        contentAlignment = Alignment.Center
    ) {
        if (file != null) {
            AsyncImage(model = file, contentDescription = "Foto profil", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(inisial.take(1).uppercase(), color = SkyDeep, fontWeight = FontWeight.Bold, fontSize = (ukuran.value / 2.2f).sp)
        }
    }
}

/** Tampilan kosong untuk daftar tanpa data */
@Composable
fun EmptyState(teks: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.Inventory2, contentDescription = null, tint = SkyBlue.copy(alpha = 0.5f), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(8.dp))
        Text(teks, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, aksi: (@Composable () -> Unit)? = null) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.onBackground)
        aksi?.invoke()
    }
}

/** Kolom input dengan sudut 12dp */
@Composable
fun EduTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    keyboardType: androidx.compose.ui.text.input.KeyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
    password: Boolean = false,
    enabled: Boolean = true,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine,
        minLines = minLines,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation()
        else androidx.compose.ui.text.input.VisualTransformation.None
    )
}

/** Dropdown pilihan berbasis teks */
@Composable
fun DropdownField(
    label: String,
    pilihan: List<String>,
    terpilih: String,
    onPilih: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var terbuka by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = terbuka && enabled,
        onExpandedChange = { if (enabled) terbuka = !terbuka },
        modifier = modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = terpilih,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = terbuka) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = terbuka && enabled, onDismissRequest = { terbuka = false }) {
            pilihan.forEachIndexed { i, teks ->
                DropdownMenuItem(
                    text = { Text(teks) },
                    onClick = { onPilih(i); terbuka = false }
                )
            }
        }
    }
}

/** Kolom tanggal dengan dialog DatePicker Material 3 */
@Composable
fun DateField(label: String, nilai: Long, onChange: (Long) -> Unit, modifier: Modifier = Modifier) {
    var tampil by remember { mutableStateOf(false) }
    Box(modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = DateUtils.formatTanggal(nilai),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.DateRange, contentDescription = null, tint = SkyBlue) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )
        // Lapisan transparan agar seluruh kolom bisa diketuk
        Box(Modifier.matchParentSize().clickable { tampil = true })
    }
    if (tampil) {
        val state = rememberDatePickerState(initialSelectedDateMillis = DateUtils.kePicker(nilai))
        DatePickerDialog(
            onDismissRequest = { tampil = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(DateUtils.dariPicker(it)) }
                    tampil = false
                }) { Text("Pilih") }
            },
            dismissButton = { TextButton(onClick = { tampil = false }) { Text("Batal") } }
        ) { DatePicker(state = state) }
    }
}

/** Dialog konfirmasi ya/tidak */
@Composable
fun ConfirmDialog(
    judul: String,
    pesan: String,
    teksYa: String = "Ya",
    onYa: () -> Unit,
    onBatal: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onBatal,
        title = { Text(judul, fontWeight = FontWeight.Bold) },
        text = { Text(pesan) },
        confirmButton = { TextButton(onClick = onYa) { Text(teksYa, color = SkyBlue, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onBatal) { Text("Batal") } },
        shape = RoundedCornerShape(16.dp)
    )
}

/** Grafik batang mini yang digambar dengan Canvas (tanpa library tambahan) */
@Composable
fun BarChartMini(labels: List<String>, nilai: List<Int>, modifier: Modifier = Modifier) {
    val maks = (nilai.maxOrNull() ?: 0).coerceAtLeast(1)
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val n = nilai.size.coerceAtLeast(1)
            val slot = size.width / n
            val lebarBar = slot * 0.5f
            nilai.forEachIndexed { i, v ->
                val tinggi = (size.height - 8.dp.toPx()) * (v.toFloat() / maks)
                val tinggiAkhir = if (v == 0) 3.dp.toPx() else tinggi
                val x = i * slot + (slot - lebarBar) / 2
                drawRoundRect(
                    color = if (v == 0) Color(0xFFBAE6FD) else SkyBlue,
                    topLeft = Offset(x, size.height - tinggiAkhir),
                    size = Size(lebarBar, tinggiAkhir),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            labels.forEachIndexed { i, l ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${nilai.getOrElse(i) { 0 }}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(l, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** Gambar QR Code dari teks (Kode Barang) */
@Composable
fun QrImage(isi: String, ukuran: Dp = 200.dp, modifier: Modifier = Modifier) {
    val bitmap: ImageBitmap = remember(isi) { QrUtils.buatQr(isi).asImageBitmap() }
    androidx.compose.foundation.Image(
        bitmap = bitmap,
        contentDescription = "QR $isi",
        modifier = modifier.size(ukuran).clip(RoundedCornerShape(12.dp))
    )
}
