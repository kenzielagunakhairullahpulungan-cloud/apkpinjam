package com.edupinjam.app.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.edupinjam.app.utils.ImageUtils
import androidx.compose.foundation.layout.fillMaxWidth
import java.io.File

/** Dua tombol: ambil foto lewat kamera atau pilih dari galeri. Hasilnya path file internal. */
@Composable
fun FotoPickerButtons(prefix: String, onFoto: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var fileSementara by remember { mutableStateOf<File?>(null) }

    val kamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { berhasil ->
        val f = fileSementara
        if (berhasil && f != null) {
            ImageUtils.kecilkanFile(f.absolutePath)
            onFoto(f.absolutePath)
        }
    }

    fun mulaiKamera() {
        val f = ImageUtils.fileBaru(context, prefix)
        fileSementara = f
        kamera.launch(ImageUtils.uriUntukFile(context, f))
    }

    val izinKamera = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { diberi ->
        if (diberi) mulaiKamera()
        else Toast.makeText(context, "Izin kamera diperlukan untuk mengambil foto", Toast.LENGTH_SHORT).show()
    }

    val galeri = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val path = ImageUtils.salinDariUri(context, uri, prefix)
            if (path != null) onFoto(path)
            else Toast.makeText(context, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
        }
    }

    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SecondaryButton(
            text = "Kamera",
            icon = Icons.Filled.CameraAlt,
            modifier = Modifier.weight(1f),
            onClick = {
                val sudah = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
                if (sudah) mulaiKamera() else izinKamera.launch(Manifest.permission.CAMERA)
            }
        )
        SecondaryButton(
            text = "Galeri",
            icon = Icons.Filled.PhotoLibrary,
            modifier = Modifier.weight(1f),
            onClick = { galeri.launch("image/*") }
        )
    }
}
