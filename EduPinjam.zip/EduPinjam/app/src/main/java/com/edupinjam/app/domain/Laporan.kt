package com.edupinjam.app.domain

import com.edupinjam.app.data.local.PeminjamanDetail

/** Ringkasan laporan satu bulan */
data class LaporanBulanan(
    val labelBulan: String,
    val totalTransaksi: Int,
    val totalUnit: Int,
    val totalDenda: Long,
    val barangPopuler: List<BarangPopuler>,
    val siswaAktif: List<SiswaAktif>,
    val transaksi: List<PeminjamanDetail>
)

/** Menyusun laporan bulanan dari daftar peminjaman (logika murni, tanpa Android) */
object LaporanBuilder {
    fun susun(label: String, awal: Long, akhir: Long, semua: List<PeminjamanDetail>): LaporanBulanan {
        val bulanIni = semua
            .filter { it.peminjaman.tanggalPinjam in awal..akhir }
            .sortedBy { it.peminjaman.tanggalPinjam }

        val populer = bulanIni
            .groupBy { it.kodeBarang }
            .map { (kode, list) -> BarangPopuler(list.first().namaBarang, kode, list.size) }
            .sortedByDescending { it.jumlah }
            .take(5)

        val aktif = bulanIni
            .groupBy { it.peminjaman.userId }
            .map { (_, list) -> SiswaAktif(list.first().namaSiswa, list.first().nisSiswa, list.size) }
            .sortedByDescending { it.jumlah }
            .take(5)

        return LaporanBulanan(
            labelBulan = label,
            totalTransaksi = bulanIni.size,
            totalUnit = bulanIni.sumOf { it.peminjaman.jumlah },
            totalDenda = bulanIni.sumOf { it.peminjaman.denda },
            barangPopuler = populer,
            siswaAktif = aktif,
            transaksi = bulanIni
        )
    }
}
