package com.edupinjam.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edupinjam.app.data.local.PeminjamanDetail
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.domain.DAY_MS
import com.edupinjam.app.domain.Denda
import com.edupinjam.app.domain.StatusPinjam
import com.edupinjam.app.utils.DateUtils
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** Data grafik 7 hari: label tanggal dan jumlah transaksi */
data class GrafikData(val label: List<String>, val nilai: List<Int>)

/** ViewModel dashboard admin/petugas */
class DashboardViewModel(repo: AppRepository) : ViewModel() {

    private fun <T> kotlinx.coroutines.flow.Flow<T>.jadiState(awal: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), awal)

    val totalBarang = repo.observeTotalStok().jadiState(0)
    val barangTersedia = repo.observeTotalTersedia().jadiState(0)
    val barangDipinjam = repo.observeJumlahDipinjam().jadiState(0)
    val barangTerlambat = repo.observeJumlahTerlambat().jadiState(0)

    /** Grafik peminjaman 7 hari terakhir (termasuk hari ini) */
    val grafik = run {
        val mulai = DateUtils.startOfDay(System.currentTimeMillis()) - 6 * DAY_MS
        val hari = (0..6).map { mulai + it * DAY_MS }
        repo.observeTanggalPinjamSejak(mulai).map { daftar ->
            GrafikData(
                label = hari.map { DateUtils.formatHariBulan(it) },
                nilai = hari.map { h -> daftar.count { it >= h && it < h + DAY_MS } }
            )
        }.jadiState(GrafikData(hari.map { DateUtils.formatHariBulan(it) }, List(7) { 0 }))
    }

    val terbaru = repo.observePeminjaman().map { it.take(5) }.jadiState(emptyList<PeminjamanDetail>())
}

/** ViewModel beranda siswa: ringkasan pinjaman milik siswa yang login */
class SiswaViewModel(repo: AppRepository, userId: Long) : ViewModel() {

    val semua: StateFlow<List<PeminjamanDetail>> = repo.observePeminjamanByUser(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aktif = semua.map { list -> list.filter { StatusPinjam.aktif(it.peminjaman.status) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalPinjam = semua.map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    /** Total denda: yang sudah tercatat ditambah denda berjalan untuk pinjaman terlambat */
    val totalDenda = semua.map { list ->
        val sekarang = System.currentTimeMillis()
        list.sumOf {
            val p = it.peminjaman
            if (StatusPinjam.aktif(p.status)) Denda.hitung(p.tanggalJatuhTempo, sekarang) else p.denda
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
}
