package com.edupinjam.app.utils

import com.edupinjam.app.domain.DAY_MS
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Utilitas tanggal dengan format Indonesia */
object DateUtils {
    private val locale = Locale("id", "ID")

    fun startOfDay(ts: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** Akhir hari (23:59:59.999), dipakai sebagai batas jatuh tempo */
    fun endOfDay(ts: Long): Long = startOfDay(ts) + DAY_MS - 1

    fun formatTanggal(ts: Long): String = SimpleDateFormat("dd MMM yyyy", locale).format(Date(ts))

    fun formatTanggalJam(ts: Long): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", locale).format(Date(ts))

    /** Label pendek untuk sumbu grafik, contoh: 21/11 */
    fun formatHariBulan(ts: Long): String = SimpleDateFormat("dd/MM", locale).format(Date(ts))

    fun formatBulan(ts: Long): String = SimpleDateFormat("MMMM yyyy", locale).format(Date(ts))

    fun awalBulan(ts: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun akhirBulan(ts: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = awalBulan(ts)
        c.add(Calendar.MONTH, 1)
        return c.timeInMillis - 1
    }

    /** Hasil DatePicker Material3 berupa tengah malam UTC; ubah ke awal hari lokal */
    fun dariPicker(utcMs: Long): Long {
        val utc = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        utc.timeInMillis = utcMs
        val lokal = Calendar.getInstance()
        lokal.clear()
        lokal.set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH))
        return lokal.timeInMillis
    }

    /** Kebalikan dari dariPicker: tanggal lokal menjadi tengah malam UTC untuk DatePicker */
    fun kePicker(localMs: Long): Long {
        val lokal = Calendar.getInstance()
        lokal.timeInMillis = localMs
        val utc = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        utc.clear()
        utc.set(lokal.get(Calendar.YEAR), lokal.get(Calendar.MONTH), lokal.get(Calendar.DAY_OF_MONTH))
        return utc.timeInMillis
    }

    /** Geser bulan: delta = -1 bulan lalu, +1 bulan depan */
    fun geserBulan(ts: Long, delta: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = awalBulan(ts)
        c.add(Calendar.MONTH, delta)
        return c.timeInMillis
    }
}

/** Format mata uang Rupiah, contoh: Rp 2.000 */
object RupiahFormat {
    fun format(nilai: Long): String =
        "Rp " + NumberFormat.getInstance(Locale("id", "ID")).format(nilai)
}

/** Hash password sederhana dengan SHA-256 */
object Security {
    fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
