package com.edupinjam.app

import android.app.Application
import com.edupinjam.app.data.local.AppDatabase
import com.edupinjam.app.data.preferences.SessionManager
import com.edupinjam.app.data.repository.AppRepository
import com.edupinjam.app.utils.NotificationHelper

/** Application class: menyimpan dependency sederhana (database, repository, session) */
class EduPinjamApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: AppRepository by lazy { AppRepository(database) }
    val session: SessionManager by lazy { SessionManager(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.buatChannel(this)
    }
}
