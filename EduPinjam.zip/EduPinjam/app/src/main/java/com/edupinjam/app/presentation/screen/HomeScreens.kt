package com.edupinjam.app.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edupinjam.app.data.local.UserEntity
import com.edupinjam.app.domain.Role
import com.edupinjam.app.presentation.viewmodel.DashboardViewModel
import com.edupinjam.app.presentation.viewmodel.SiswaViewModel
import com.edupinjam.app.presentation.viewmodel.rememberApp
import com.edupinjam.app.presentation.viewmodel.vmFactory
import com.edupinjam.app.ui.components.BarChartMini
import com.edupinjam.app.ui.components.EduCard
import com.edupinjam.app.ui.components.EmptyState
import com.edupinjam.app.ui.components.SectionTitle
import com.edupinjam.app.ui.theme.GreenOk
import com.edupinjam.app.ui.theme.RedBad
import com.edupinjam.app.ui.theme.SkyBlue
import com.edupinjam.app.ui.theme.SkyDeep
import com.edupinjam.app.ui.theme.White
import com.edupinjam.app.ui.theme.YellowWarn
import com.edupinjam.app.utils.RupiahFormat

/** Header beranda dengan sapaan */
@Composable
private fun HeaderBeranda(user: UserEntity, sub: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(SkyBlue, SkyDeep)))
            .padding(start = 20.dp, end = 20.dp, top = 40.dp, bottom = 24.dp)
    ) {
        Column {
            Text("Halo, ${user.nama.substringBefore(' ')}!", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("${Role.label(user.role)} - $sub", color = White.copy(alpha = 0.9f), fontSize = 13.sp)
        }
    }
}

/** Kartu angka ringkasan */
@Composable
private fun StatCard(label: String, nilai: Int, ikon: ImageVector, warna: Color, modifier: Modifier = Modifier) {
    EduCard(modifier) {
        Icon(ikon, contentDescription = null, tint = warna, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(6.dp))
        Text("$nilai", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = warna)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Tombol cepat berbentuk kartu kecil */
@Composable
private fun TombolCepat(label: String, ikon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    EduCard(modifier, onClick = onClick) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(SkyBlue),
                contentAlignment = Alignment.Center
            ) { Icon(ikon, contentDescription = null, tint = White) }
            Spacer(Modifier.height(6.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Dashboard Admin / Petugas */
@Composable
fun DashboardScreen(
    user: UserEntity,
    onTambahBarang: () -> Unit,
    onPinjam: () -> Unit,
    onScan: () -> Unit,
    onLihatSemua: () -> Unit
) {
    val app = rememberApp()
    val vm: DashboardViewModel = viewModel(factory = vmFactory { DashboardViewModel(app.repository) })
    val total by vm.totalBarang.collectAsStateWithLifecycle()
    val tersedia by vm.barangTersedia.collectAsStateWithLifecycle()
    val dipinjam by vm.barangDipinjam.collectAsStateWithLifecycle()
    val terlambat by vm.barangTerlambat.collectAsStateWithLifecycle()
    val grafik by vm.grafik.collectAsStateWithLifecycle()
    val terbaru by vm.terbaru.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        HeaderBeranda(user, "Dashboard inventaris sekolah")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Total Barang", total, Icons.Filled.Inventory2, SkyBlue, Modifier.weight(1f))
                StatCard("Barang Tersedia", tersedia, Icons.Filled.CheckCircle, GreenOk, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Barang Dipinjam", dipinjam, Icons.Filled.Timer, YellowWarn, Modifier.weight(1f))
                StatCard("Barang Terlambat", terlambat, Icons.Filled.Warning, RedBad, Modifier.weight(1f))
            }

            SectionTitle("Aksi Cepat")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TombolCepat("Tambah Barang", Icons.Filled.AddBox, onTambahBarang, Modifier.weight(1f))
                TombolCepat("Pinjam Barang", Icons.Filled.SwapHoriz, onPinjam, Modifier.weight(1f))
                TombolCepat("Scan QR", Icons.Filled.QrCodeScanner, onScan, Modifier.weight(1f))
            }

            SectionTitle("Peminjaman 7 Hari Terakhir")
            EduCard(Modifier.fillMaxWidth()) {
                BarChartMini(grafik.label, grafik.nilai)
            }

            SectionTitle("Peminjaman Terbaru") {
                androidx.compose.material3.TextButton(onClick = onLihatSemua) { Text("Lihat Semua", color = SkyBlue) }
            }
            if (terbaru.isEmpty()) EmptyState("Belum ada peminjaman")
            terbaru.forEach { PeminjamanItem(it) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/** Beranda siswa: ringkasan pinjaman milik sendiri */
@Composable
fun SiswaHomeScreen(user: UserEntity, onPinjam: () -> Unit, onScan: () -> Unit) {
    val app = rememberApp()
    val vm: SiswaViewModel = viewModel(key = "siswa_home_${user.id}", factory = vmFactory { SiswaViewModel(app.repository, user.id) })
    val aktif by vm.aktif.collectAsStateWithLifecycle()
    val total by vm.totalPinjam.collectAsStateWithLifecycle()
    val denda by vm.totalDenda.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        HeaderBeranda(user, "${user.kelas} - NIS ${user.nis}")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Sedang Dipinjam", aktif.size, Icons.Filled.Timer, YellowWarn, Modifier.weight(1f))
                StatCard("Total Pinjam", total, Icons.Filled.SwapHoriz, SkyBlue, Modifier.weight(1f))
            }
            EduCard(Modifier.fillMaxWidth()) {
                Text("Total Denda", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    RupiahFormat.format(denda), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                    color = if (denda > 0) RedBad else GreenOk
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TombolCepat("Pinjam Barang", Icons.Filled.SwapHoriz, onPinjam, Modifier.weight(1f))
                TombolCepat("Scan QR", Icons.Filled.QrCodeScanner, onScan, Modifier.weight(1f))
            }
            SectionTitle("Pinjaman Saya yang Aktif")
            if (aktif.isEmpty()) EmptyState("Tidak ada barang yang sedang dipinjam")
            aktif.forEach { PeminjamanItem(it, tampilkanSiswa = false) }
            Spacer(Modifier.height(8.dp))
        }
    }
}
