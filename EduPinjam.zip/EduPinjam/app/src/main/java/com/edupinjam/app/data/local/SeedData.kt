package com.edupinjam.app.data.local

import com.edupinjam.app.domain.Kondisi
import com.edupinjam.app.domain.Role
import com.edupinjam.app.utils.Security

/** Data awal: akun demo dan 15 barang inventaris sekolah */
object SeedData {

    fun users(): List<UserEntity> = listOf(
        UserEntity(
            nama = "Administrator", username = "admin",
            passwordHash = Security.sha256("admin123"), role = Role.ADMIN
        ),
        UserEntity(
            nama = "Bu Ratna (Petugas)", username = "petugas",
            passwordHash = Security.sha256("petugas123"), role = Role.PETUGAS
        ),
        UserEntity(
            nama = "Andi Pratama", username = "1001",
            passwordHash = Security.sha256("siswa123"), role = Role.SISWA,
            nis = "1001", kelas = "X IPA 1", noHp = "081234567801"
        ),
        UserEntity(
            nama = "Siti Nurhaliza", username = "1002",
            passwordHash = Security.sha256("siswa123"), role = Role.SISWA,
            nis = "1002", kelas = "XI IPS 2", noHp = "081234567802"
        ),
        UserEntity(
            nama = "Budi Santoso", username = "1003",
            passwordHash = Security.sha256("siswa123"), role = Role.SISWA,
            nis = "1003", kelas = "XII IPA 3", noHp = "081234567803"
        )
    )

    private fun b(
        nama: String, kategori: String, kode: String, stok: Int,
        kondisi: String = Kondisi.BAIK, rak: String
    ) = BarangEntity(
        nama = nama, kategori = kategori, kode = kode,
        stokTotal = stok, stokTersedia = stok, kondisi = kondisi, lokasiRak = rak
    )

    fun barang(): List<BarangEntity> = listOf(
        b("Proyektor Epson", "Elektronik", "EDU-001", 3, rak = "Rak A1"),
        b("Laptop Lenovo", "Elektronik", "EDU-002", 10, rak = "Rak A2"),
        b("Bola Basket", "Olahraga", "EDU-003", 6, rak = "Gudang Olahraga"),
        b("Mikroskop Binokuler", "Lab", "EDU-004", 5, rak = "Lab IPA - Rak 1"),
        b("Gitar Akustik", "Musik", "EDU-005", 4, rak = "Ruang Musik"),
        b("Buku Atlas Dunia", "Buku", "EDU-006", 12, rak = "Perpustakaan B3"),
        b("Kamera DSLR", "Elektronik", "EDU-007", 2, rak = "Rak A3"),
        b("Bola Voli", "Olahraga", "EDU-008", 6, rak = "Gudang Olahraga"),
        b("Keyboard Piano", "Musik", "EDU-009", 2, rak = "Ruang Musik"),
        b("Set Tabung Reaksi", "Lab", "EDU-010", 20, rak = "Lab Kimia - Rak 2"),
        b("Kalkulator Ilmiah", "Alat Tulis", "EDU-011", 15, rak = "Rak C1"),
        b("Set Jangka & Busur", "Alat Tulis", "EDU-012", 10, rak = "Rak C2"),
        b("Kamus Besar Bahasa Indonesia", "Buku", "EDU-013", 8, rak = "Perpustakaan A1"),
        b("Raket Badminton", "Olahraga", "EDU-014", 8, Kondisi.RUSAK_RINGAN, "Gudang Olahraga"),
        b("Speaker Portable", "Lainnya", "EDU-015", 3, rak = "Rak A4")
    )
}
