# Aturan ProGuard EDU-PINJAM (tidak ada aturan khusus untuk build debug)
